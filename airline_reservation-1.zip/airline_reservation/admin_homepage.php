<?php session_start(); ?>
<html>
<head>
	<title>Welcome Administrator</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		body {
			margin: 0;
			font-family: 'Segoe UI', sans-serif;
			background: linear-gradient(rgba(0,0,0,0.55),rgba(0,0,0,0.55)),
			            url('images/admin_bg_plane.jpg') no-repeat center center fixed;
			background-size: cover;
			color: #001a4d;
			min-height: 100vh;
		}
		.logo {
			display: block;
			margin: 20px auto 10px;
			width: 100px;
			height: 100px;
			border-radius: 50%;
			object-fit: cover;
			box-shadow: 0 4px 15px rgba(0,0,0,0.15);
			background: #fff;
		}
		#title {
			display: block;
			text-align: center;
			font-size: 28px;
			font-weight: bold;
			letter-spacing: 2px;
			color: #fff;
			text-shadow: 0 2px 6px rgba(0,0,0,0.5);
		}
		.admin-nav-wrap {
			text-align: center;
		}
		ul {
			list-style-type: none;
			background-color: rgba(0,0,0,0.1);
			padding: 0;
			margin: 0 auto;
			display: inline-block;
			border-radius: 8px;
			box-shadow: 0 4px 15px rgba(0,0,0,0.1);
		}
		ul li {
			display: inline-block;
			float: none;
		}
		ul li a {
			display: block;
			color: #66004e;
			padding: 14px 20px;
			text-decoration: none;
			transition: background 0.3s ease, color 0.3s ease;
			font-weight: 600;
		}
		ul li a:hover {
			background-color: #003366;
			color: #fff;
			border-radius: 6px;
		}
		h2 {
			text-align: center;
			margin-top: 40px;
			font-size: 32px;
			color: #fff;
			text-shadow: 0 2px 6px rgba(0,0,0,0.5);
		}
		.admin-card-container {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			margin-top: 40px;
			gap: 25px;
		}
		.admin-card {
			background: #ffffff;
			width: 280px;
			height: 80px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 12px;
			box-shadow: 0 4px 15px rgba(0,0,0,0.2);
			transition: all 0.3s ease;
			text-align: center;
			font-size: 18px;
			font-weight: 600;
			color: #003f66;
			text-decoration: none;
		}
		.admin-card i {
			margin-right: 10px;
			font-size: 22px;
		}
		.admin-card:hover {
			background-color: #cce0ff;
			transform: translateY(-5px);
			box-shadow: 0 8px 25px rgba(0,0,0,0.3);
		}
		@media (max-width: 768px) {
			.admin-card-container {
				flex-direction: column;
				align-items: center;
			}
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body class="admin-homepage">
	<img class="logo" src="images/Og.jpeg"> 
	<h1 id="title">SKY HIGH AIRLINES</h1>

	<div class="admin-nav-wrap">
		<ul>
			<li><a href="admin_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="admin_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<h2>Welcome Administrator!</h2>

	<div class="admin-card-container">
		<a class="admin-card" href="admin_view_booked_tickets.php">
			<i class="fa fa-plane"></i> View Booked Tickets
		</a>
		<a class="admin-card" href="add_flight_details.php">
			<i class="fa fa-plus-circle"></i> Add Flight Schedule
		</a>
		<a class="admin-card" href="delete_flight_details.php">
			<i class="fa fa-trash"></i> Delete Flight Schedule
		</a>
		<a class="admin-card" href="view_flights.php">
			<i class="fa fa-eye"></i> View Added Flights
		</a>
		<a class="admin-card" href="admin_view_messages.php">
			<i class="fa fa-envelope"></i> View Customer Messages
		</a>
	</div>
</body>
</html>
