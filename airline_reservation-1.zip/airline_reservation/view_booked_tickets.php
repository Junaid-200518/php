<?php
	session_start();
?>
<html>
<head>
    <title>View Booked Tickets</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f7fc;
            margin: 0;
            padding: 0;
        }
        .logo {
            width: 100px;
            margin: 20px;
        }
        #title {
            text-align: center;
            color: #030337;
            font-size: 36px;
            margin-top: -20px;
        }
        ul {
            list-style-type: none;
            background: #030337;
            overflow: hidden;
            padding: 0;
            margin: 0;
        }
        ul li {
            float: left;
        }
        ul li a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 14px 20px;
        }
        ul li a:hover {
            background: #57578a;
        }

        h2 {
            text-align: center;
            color: #030337;
            margin-top: 20px;
        }
        h3 {
            text-align: center;
            color: #444;
        }

        .ticket-table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        }
        .ticket-table th {
            background: #030337;
            color: white;
            padding: 12px;
            font-size: 16px;
            text-align: center;
        }
        .ticket-table th.journey-date, .ticket-table td.journey-date {
            min-width: 130px;
            max-width: 160px;
            word-break: break-word;
        }
        .ticket-table td {
            text-align: center;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            font-size: 15px;
        }
        .ticket-table tr:nth-child(even) {
            background: #f8f8f8;
        }
        .ticket-table tr:hover {
            background: #e9eefc;
        }
        .no-data {
            text-align: center;
            color: #666;
            font-size: 18px;
            margin: 20px 0;
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
    <h1 id="title">SKY HIGH AIRLINES</h1>
    <div>
        <ul>
            <li><a href="customer_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
            <li><a href="customer_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
            <li><a href="home_page.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
            <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
        </ul>
    </div>

    <h2>View Booked Flight Tickets</h2>
    <h3><u>Upcoming Trips</u></h3>
    <?php
        $todays_date=date('Y-m-d');
        $thirty_days_before_date=date_create(date('Y-m-d'));
        date_sub($thirty_days_before_date,date_interval_create_from_date_string("30 days")); 
        $thirty_days_before_date=date_format($thirty_days_before_date,"Y-m-d");
        
        $customer_id=$_SESSION['login_user'];
        require_once('Database Connection file/mysqli_connect.php');
        $query="SELECT td.pnr, td.date_of_reservation, td.flight_no, fd.from_city, fd.to_city, fd.departure_time, td.journey_date, td.class, td.booking_status, td.no_of_passengers, td.payment_id 
            FROM Ticket_Details td 
            JOIN flight_details fd ON td.flight_no = fd.flight_no 
            WHERE td.customer_id=? AND td.journey_date>=? AND td.booking_status='CONFIRMED' 
            ORDER BY td.journey_date";
        $stmt=mysqli_prepare($dbc,$query);
        mysqli_stmt_bind_param($stmt,"ss",$customer_id,$todays_date);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt,$pnr,$date_of_reservation,$flight_no,$from_city,$to_city,$departure_time,$journey_date,$class,$booking_status,$no_of_passengers,$payment_id);
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt)==0)
        {
            echo "<div class='no-data'>No upcoming trips!</div>";
        }
        else
        {
            echo "<table class='ticket-table'>";
            echo "<tr><th>PNR</th>
            <th>Date of Reservation</th>
            <th>Flight No.</th>
            <th>From</th>
            <th>Destination</th>
            <th>Departure Time</th>
            <th class='journey-date'>Journey Date</th>
            <th>Class</th>
            <th>Booking Status</th>
            <th>No. of Passengers</th>
            <th>Payment ID</th></tr>";
            while(mysqli_stmt_fetch($stmt)) {
                echo "<tr>
                <td><a href='show_ticket.php?pnr=".$pnr."' style='color:#003366;text-decoration:underline;' target='_blank'>".$pnr."</a></td>
                <td>".$date_of_reservation."</td>
                <td>".$flight_no."</td>
                <td>".$from_city."</td>
                <td>".$to_city."</td>
                <td>".$departure_time."</td>
                <td class='journey-date'>".$journey_date."</td>
                <td>".$class."</td>
                <td>".$booking_status."</td>
                <td>".$no_of_passengers."</td>
                <td>".$payment_id."</td>
                </tr>";
            }
            echo "</table>";
        }
        echo "<h3><u>Completed Trips</u></h3>";

        $query="SELECT pnr,date_of_reservation,flight_no,journey_date,class,booking_status,no_of_passengers,payment_id 
                FROM Ticket_Details 
                WHERE customer_id=? and journey_date<? and journey_date>=? 
                ORDER BY journey_date";
        $stmt=mysqli_prepare($dbc,$query);
        mysqli_stmt_bind_param($stmt,"sss",$customer_id,$todays_date,$thirty_days_before_date);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt,$pnr,$date_of_reservation,$flight_no,$journey_date,$class,$booking_status,$no_of_passengers,$payment_id);
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt)==0)
        {
            echo "<div class='no-data'>No trips completed in the past 30 days!</div>";
        }
        else
        {
            echo "<table class='ticket-table'>";
            echo "<tr><th>PNR</th>
            <th>Date of Reservation</th>
            <th>Flight No.</th>
            <th>Journey Date</th>
            <th>Class</th>
            <th>Booking Status</th>
            <th>No. of Passengers</th>
            <th>Payment ID</th></tr>";
            while(mysqli_stmt_fetch($stmt)) {
                echo "<tr>
                <td>".$pnr."</td>
                <td>".$date_of_reservation."</td>
                <td>".$flight_no."</td>
                <td>".$journey_date."</td>
                <td>".$class."</td>
                <td>".$booking_status."</td>
                <td>".$no_of_passengers."</td>
                <td>".$payment_id."</td>
                </tr>";
            }
            echo "</table>";
        }
        mysqli_stmt_close($stmt);
        mysqli_close($dbc);
    ?>
</body>
</html>
