<?php
	session_start();
?>
<html>
<head>
	<title>Delete Flight Schedule - SKY HIGH Airlines</title>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		body {
			margin: 0;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			background: #e6f0ff; /* Light blue background */
			color: #030337;
		}
		.logo {
			height: 70px;
			margin: 15px 20px;
		}
		#title {
			display: inline-block;
			font-size: 28px;
			font-weight: bold;
			color: #030337;
			vertical-align: middle;
		}
		ul {
			list-style: none;
			background: #030337;
			padding: 0;
			margin: 0 0 20px 0;
			overflow: hidden;
			border-radius: 8px;
		}
		ul li {
			float: left;
		}
		ul li a {
			display: block;
			color: #fff;
			padding: 12px 20px;
			text-decoration: none;
			transition: 0.3s;
		}
		ul li a:hover {
			background: #6699ff;
		}
		h2 {
			text-align: center;
			margin: 30px 0 20px;
			color: #030337;
		}
		form {
			background: #fff;
			width: 60%;
			margin: 0 auto 40px auto;
			padding: 25px;
			border-radius: 10px;
			box-shadow: 0 5px 15px rgba(0,0,0,0.1);
		}
		table {
			width: 100%;
			border-collapse: collapse;
		}
		td {
			padding: 12px;
			font-size: 15px;
		}
		input[type=text], input[type=date] {
			width: 95%;
			padding: 8px 12px;
			border: 1.5px solid #030337;
			border-radius: 5px;
			font-size: 14px;
		}
		input[type=submit] {
			background-color: #030337;
			color: white;
			border-radius: 5px;
			padding: 10px 50px;
			margin: 20px 0;
			cursor: pointer;
			font-size: 16px;
			transition: 0.3s;
			display: block;
			margin-left: auto;
			margin-right: auto;
		}
		input[type=submit]:hover {
			background-color: #6699ff;
		}
		.message {
			text-align: center;
			font-weight: bold;
			margin-bottom: 20px;
		}
		.message.success { color: green; }
		.message.error { color: red; }
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<div style="display:flex; align-items:center; padding:10px 20px;">
		<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
		<h1 id="title">SKY HIGH AIRLINES</h1>
	</div>

	<div>
		<ul>
			<li><a href="admin_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="admin_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<form action="delete_flight_details_form_handler.php" method="post">
		<h2>Delete Flight Schedule</h2>
		<?php
			if(isset($_GET['msg']) && $_GET['msg']=='success') {
				echo "<div class='message success'>The Flight Schedule has been successfully deleted.</div>";
			} else if(isset($_GET['msg']) && $_GET['msg']=='failed') {
				echo "<div class='message error'>*Invalid Flight No./Departure Date. Please try again.</div>";
			}
		?>
		<table>
			<tr>
				<td>Enter Flight No.</td>
				<td>Enter Departure Date</td>
			</tr>
			<tr>
				<td><input type="text" name="flight_no" required></td>
				<td><input type="date" name="departure_date" required></td>
			</tr>
		</table>
		<input type="submit" value="Delete" name="Delete">
	</form>
</body>
</html>
