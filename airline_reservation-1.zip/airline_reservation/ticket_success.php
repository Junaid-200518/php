<?php
session_start();

// init flags before any HTML
$insert_success = false;
$insert_error   = '';

// Save passenger details from POST to variables
$passenger_details = array();
if (isset($_POST['passenger_details']) && is_array($_POST['passenger_details'])) {
    $passenger_details = $_POST['passenger_details'];
}

// Insert passenger details into booking_details table
require_once('Database Connection file/mysqli_connect.php');

$pnr         = isset($_POST['pnr']) ? $_POST['pnr'] : (isset($_SESSION['pnr']) ? $_SESSION['pnr'] : '');
$flight_no   = isset($_POST['flight_no']) ? $_POST['flight_no'] : (isset($_SESSION['flight_no']) ? $_SESSION['flight_no'] : '');
$journey_date= isset($_POST['journey_date']) ? $_POST['journey_date'] : (isset($_SESSION['journey_date']) ? $_SESSION['journey_date'] : '');

if (!empty($passenger_details) && $pnr && $flight_no && $journey_date) {
    try {
        foreach ($passenger_details as $passenger) {
            $p_name = isset($passenger['p_name']) ? $passenger['p_name'] : '';
            $gender = isset($passenger['gender']) ? $passenger['gender'] : '';
            $seat_no = rand(1,100); // Random seat number for demonstration
            $p_age = isset($passenger['age']) ? $passenger['age'] : '';
            $meal_choice = isset($passenger['meal_choice']) ? $passenger['meal_choice'] : '';

            $stmt = $dbc->prepare("INSERT INTO booking_details (pnr, flight_no, journey_date, p_name, gender, age, seat_no) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssss", $pnr, $flight_no, $journey_date, $p_name, $gender, $p_age, $seat_no);
            $stmt->execute();
            $stmt->close();
        }
        $insert_success = true;
    } catch (Exception $e) {
        $insert_error = $e->getMessage();
        $insert_success = false;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ticket Booking Successful</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f7fc;
            margin: 0;
            padding: 0;
        }
        .logo {
            width: 100px;
            margin: 20px;
        }
        #title {
            text-align: center;
            color: #030337;
            font-size: 36px;
            margin-top: -20px;
        }
        ul {
            list-style-type: none;
            background: #030337;
            overflow: hidden;
            padding: 0;
            margin: 0;
        }
        ul li {
            float: left;
        }
        ul li a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 14px 20px;
        }
        ul li a:hover {
            background: #57578a;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin: 40px auto;
            padding: 30px;
            width: 70%;
            text-align: center;
        }
        .success-icon {
            color: #28a745;
            font-size: 60px;
            margin-bottom: 15px;
        }
        h2 {
            color: #28a745;
            font-size: 28px;
            margin: 10px 0;
        }
        .pnr {
            font-size: 24px;
            color: #030337;
            font-weight: bold;
        }
        .amount {
            font-size: 20px;
            margin-top: 10px;
        }
        .btn {
            background-color: #030337;
            color: white;
            padding: 12px 40px;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 25px;
            display: inline-block;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #57578a;
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <img class="logo" src="images/IMG_20250921_131245.jpg"/> 


    <h1 id="title">SKY HIGH AIRLINES</h1>
    <div>
        <ul>
            <li><a href="customer_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
            <li><a href="customer_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
            <li><a href="home_page.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
            <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
        </ul>
    </div>

    <div class="card">
        <?php if (!$insert_success && !empty($insert_error)): ?>
            <div style="color: red; font-weight: bold; margin-bottom: 15px;">
                Error saving passenger details: <?php echo htmlspecialchars($insert_error); ?>
            </div>
        <?php elseif ($insert_success && !empty($passenger_details)): ?>
            <div style="color: #28a745; font-weight: bold; margin-bottom: 15px;">
                Passenger details saved successfully!
            </div>
        <?php endif; ?>

        <i class="fa fa-check-circle success-icon"></i>
        <h2>Booking Successful!</h2>
        <p class="amount">
            Your payment of &#x20b9;
            <strong><?php echo isset($_POST['total_amount']) ? $_POST['total_amount'] : (isset($_SESSION['total_amount']) ? $_SESSION['total_amount'] : ''); ?></strong>
            has been received.
        </p>
        <p>
            Your PNR is 
            <span class="pnr"><?php echo $pnr ? $pnr : 'N/A'; ?></span>.<br>
            Your tickets have been booked successfully.
        </p>
        <?php if ($pnr): ?>
        <a href="show_ticket.php?pnr=<?php echo urlencode($pnr); ?>" class="btn" style="background-color:#ff6600;"><i class="fa fa-print"></i> View / Print Ticket</a>
        <?php endif; ?>
        <a href="customer_homepage.php" class="btn"><i class="fa fa-desktop"></i> Go to Dashboard</a>
    </div>
    <?php
        // Clear session variables related to booking
        unset($_SESSION['pnr']);
       
        unset($_SESSION['journey_date']);
        unset($_SESSION['no_of_pass']);
        unset($_SESSION['class']);
        unset($_SESSION['total_amount']);
        unset($_SESSION['payment_id']);
        unset($_SESSION['payment_date']);
    // Close database connection
    mysqli_close($dbc);
    ?>
</body>
</html>
