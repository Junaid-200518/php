<?php
session_start();
require_once('Database Connection file/mysqli_connect.php');
require_once('contact_messages_setup.php');

ensure_contact_messages_table($dbc);

$customer_email = '';
$customer_id = isset($_SESSION['login_user']) ? trim($_SESSION['login_user']) : '';

if ($customer_id !== '') {
    $query = "SELECT email FROM Customer WHERE customer_id = ? LIMIT 1";
    $stmt = mysqli_prepare($dbc, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $customer_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $customer_email);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
    }
}

$result = false;
$db_error = false;
if ($customer_id !== '') {
    // Match messages to the logged-in customer first. Email is kept as a
    // fallback for older messages created before customer_id was stored.
    $query = "SELECT id, message, reply, replied_at, submitted_at
              FROM contact_messages
              WHERE customer_id = ? OR (customer_id IS NULL AND email = ?)
              ORDER BY id DESC";
    $stmt = mysqli_prepare($dbc, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $customer_id, $customer_email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $msg_id, $msg_text, $msg_reply, $msg_replied_at, $msg_submitted_at);
        $messages = array();
        while (mysqli_stmt_fetch($stmt)) {
            $messages[] = array(
                'id' => $msg_id,
                'message' => $msg_text,
                'reply' => $msg_reply,
                'replied_at' => $msg_replied_at,
                'submitted_at' => $msg_submitted_at
            );
        }
        mysqli_stmt_close($stmt);
        $result = $messages;
    } else {
        $db_error = true;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Messages - SKY HIGH Airlines</title>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #e6f0ff;
            margin: 0;
            padding: 0;
            color: #030337;
        }
        h2 {
            text-align: center;
            margin-top: 40px;
            font-size: 28px;
        }
        .messages-wrap {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .message-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 18px 20px;
            margin-bottom: 20px;
        }
        .message-card .meta {
            color: #888;
            font-size: 0.85em;
            margin-bottom: 6px;
        }
        .message-card .msg-text {
            margin-bottom: 12px;
        }
        .reply-box {
            background: #f7faff;
            border: 1px solid #cfe0ff;
            border-radius: 8px;
            padding: 10px 12px;
        }
        .reply-box strong { color: #003366; }
        .no-reply { color: #888; font-style: italic; }
        .button-container {
            text-align: center;
            margin: 20px 0 40px;
        }
        .button-container a button {
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px 30px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        .button-container a button:hover {
            background-color: #ff6600;
        }
    </style>
    <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <h2>My Messages &amp; Replies</h2>
    <div class="messages-wrap">
        <?php if ($db_error): ?>
            <p style="text-align:center;color:#c0392b;">The Contact Us database could not be prepared. Please check that MySQL is running and the project is connected to the correct database.</p>
        <?php elseif (is_array($result) && count($result) > 0): ?>
            <?php foreach($result as $row): ?>
                <div class="message-card">
                    <div class="meta">Sent: <?php echo htmlspecialchars($row['submitted_at']); ?></div>
                    <div class="msg-text"><?php echo nl2br(htmlspecialchars($row['message'])); ?></div>
                    <?php if (!empty($row['reply'])): ?>
                        <div class="reply-box">
                            <strong>Airline Reply<?php echo !empty($row['replied_at']) ? ' ('.htmlspecialchars($row['replied_at']).')' : ''; ?>:</strong><br>
                            <?php echo nl2br(htmlspecialchars($row['reply'])); ?>
                        </div>
                    <?php else: ?>
                        <div class="no-reply">No reply yet. Our team will get back to you soon.</div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align:center;">You haven't sent us any messages yet, or none were found for your account email.</p>
        <?php endif; ?>
    </div>

    <div class="button-container">
        <a href="customer_homepage.php"><button>Back to Dashboard</button></a>
    </div>
</body>
</html>
<?php
if (isset($dbc)) mysqli_close($dbc);
?>
