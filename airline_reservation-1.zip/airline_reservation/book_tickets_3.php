
<?php
session_start();
require_once('Database Connection file/mysqli_connect.php');


if (isset($_POST['Submit'])) {
    $flight_no = $_POST['flight_no'];
    $num_passengers = $_POST['no_pass'];
    $class = $_POST['class'];
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
    // insert booking
    $insert = "INSERT INTO ticket_details (flight_no, no_of_passengers, class)
                 VALUES ('$flight_no', '$num_passengers', '$class')";
    if (mysqli_query($dbc, $insert)) {
        echo "<div style='color:white;text-align:center;margin-top:40px;font-size:1.3rem;'>Booking successful!<br><a href='customer_homepage.php' style='color:#ff6600;'>Go Back</a></div>";
    } else {
        echo "<div style='color:white;text-align:center;margin-top:40px;font-size:1.3rem;'>Error: " . mysqli_error($dbc) . "<br><a href='customer_homepage.php' style='color:#ff6600;'>Go Back</a></div>";
    }
    exit;
}

$flight_no = $_POST['flight_no'];
$_SESSION['flight_no'] = $flight_no;
$journey_date = $_POST['journey_date'];
$_SESSION['journey_date'] = $journey_date;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Book Tickets</title>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)), url('images/background.jpeg') no-repeat center center fixed;
            background-size: cover;
            color: #222;
            min-height: 100vh;
        }
        .logo {
            display: block;
            margin: 20px auto 10px;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            background: #fff;
        }
        #title {
            text-align: center;
            font-size: 2rem;
            font-weight: 700;
            color: #fff;
            text-shadow: 0 2px 6px rgba(0,0,0,0.5);
            margin-bottom: 10px;
        }
        ul {
            list-style: none;
            margin: 0;
            padding: 8px 0;
            background: rgba(0,51,102,0.9);
            text-align: center;
            width: 100%;
            border-radius: 0 0 12px 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        ul li {
            display: inline-block;
            margin: 0 8px;
        }
        ul li a {
            color: #fff;
            text-decoration: none;
            padding: 10px 16px;
            border-radius: 6px;
            font-weight: 500;
            transition: 0.3s;
        }
        ul li a:hover {
            background: #ff6600;
            box-shadow: 0 2px 8px rgba(255,102,0,0.25);
        }
        .form-container {
            background: rgba(255,255,255,0.97);
            max-width: 420px;
            margin: 40px auto 0;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.13);
            padding: 32px 28px 24px;
            text-align: center;
        }
        .form-container h2 {
            color: #003366;
            margin-bottom: 18px;
            font-size: 1.4rem;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #003366;
            font-weight: 500;
            text-align: left;
        }
        input, select {
            border: 1.5px solid #003366;
            border-radius: 6px;
            padding: 8px 12px;
            font-size: 0.95rem;
            width: 100%;
            margin-bottom: 16px;
            box-sizing: border-box;
        }
        input[type=submit] {
            background-color: #003366;
            color: white;
            border-radius: 6px;
            padding: 10px 45px;
            margin-top: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: 0.3s;
            width: auto;
        }
        input[type=submit]:hover {
            background: #ff6600;
            box-shadow: 0 4px 12px rgba(255,102,0,0.25);
        }
        @media(max-width:600px){
            .form-container{padding:18px 8px;}
            .form-container h2{font-size:1.1rem;}
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
    <h1 id="title">SKY HIGH AIRLINES</h1>
    <div>
        <ul>
            <li><a href="customer_homepage.php"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="customer_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
            <li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
            <li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
        </ul>
    </div>
    <div class="form-container">
        <h2>Book Flight <?php echo htmlspecialchars($flight_no); ?></h2>
        <form action="book_tickets2.php" method="post">
            <input type="hidden" name="flight_no" value="<?php echo htmlspecialchars($flight_no); ?>">
            <label for="num_passengers">No. of Passengers (Adults):</label>
            <input type="number" name="no_of_pass" id="num_passengers" min="1" required>
            <label for="num_children">No. of Children (below 12 yrs):</label>
            <input type="number" name="no_of_child" id="num_children" min="0" value="0">
            <label for="class">Class:</label>
            <select name="class" id="class" required>
                <option value="economy">Economy</option>
                <option value="business">Business</option>
            </select>
            <input type="hidden" name="journey_date" value="<?php echo htmlspecialchars($journey_date); ?>">
            <input type="submit" name="Submit" value="Book Ticket">
        </form>
    </div>
</body>
</html>
