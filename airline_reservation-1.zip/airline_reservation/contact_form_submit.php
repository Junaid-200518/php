<?php
session_start();
require_once('Database Connection file/mysqli_connect.php');
require_once('contact_messages_setup.php');

if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
}

// Ensure the Contact Us table and reply fields exist.
if (!ensure_contact_messages_table($dbc)) {
    die("Could not prepare the Contact Us database table.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = trim($_POST["name"] ?? '');
    $email   = trim($_POST["email"] ?? '');
    $message = trim($_POST["message"] ?? '');
    $customer_id = isset($_SESSION['login_user']) ? trim($_SESSION['login_user']) : null;

    if ($name === '' || $email === '' || $message === '') {
        echo "<h2>Please fill in all Contact Us fields.</h2>";
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<h2>Invalid email address.</h2>";
        exit();
    }

    $query = "INSERT INTO contact_messages (customer_id, name, email, message) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($dbc, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $customer_id, $name, $email, $message);
        if (!mysqli_stmt_execute($stmt)) {
            echo "<h2>Could not submit your message: " . htmlspecialchars(mysqli_stmt_error($stmt)) . "</h2>";
            mysqli_stmt_close($stmt);
            mysqli_close($dbc);
            exit();
        }

        $return_link = 'home_page.php';
        $return_label = 'Return Home';
        if (isset($_SESSION['login_user']) && isset($_SESSION['user_type'])) {
            if ($_SESSION['user_type'] == 'Customer') {
                $return_link = 'customer_homepage.php';
                $return_label = 'Return to Dashboard';
            } elseif ($_SESSION['user_type'] == 'Administrator') {
                $return_link = 'admin_homepage.php';
                $return_label = 'Return to Dashboard';
            }
        }

        echo "<!DOCTYPE html>
        <html>
        <head>
            <title>Message Received - SKY HIGH Airlines</title>
            <link rel='stylesheet' href='font-awesome-4.7.0/css/font-awesome.min.css'>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: #e6f0ff;
                    margin: 0;
                    padding: 0;
                    color: #001a4d;
                }

                .contact-section {
                    max-width: 600px;
                    margin: 80px auto;
                    background: #ffffff;
                    padding: 40px 30px;
                    border-radius: 12px;
                    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
                    text-align: center;
                }

                .contact-section h2 {
                    color: #003366;
                    font-size: 28px;
                    margin-bottom: 20px;
                }

                .contact-section p {
                    font-size: 16px;
                    line-height: 1.6;
                    margin-bottom: 30px;
                }

                .contact-section a button {
                    background-color: #003366;
                    color: white;
                    border: none;
                    padding: 12px 28px;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 6px;
                    cursor: pointer;
                    transition: 0.3s;
                }

                .contact-section a button:hover {
                    background-color: #6699ff;
                }

                /* Responsive */
                @media (max-width: 600px) {
                    .contact-section {
                        margin: 40px 20px;
                        padding: 30px 20px;
                    }

                    .contact-section h2 {
                        font-size: 24px;
                    }

                    .contact-section p {
                        font-size: 15px;
                    }
                }
            </style>
          <link rel='stylesheet' href='css/theme.css'>
</head>
        <body>
            <div class='contact-section'>
                <h2><i class='fa fa-envelope'></i> Thank you, $name!</h2>
                <p>Your message has been successfully submitted. We’ll get back to you as soon as possible.</p>
                <a href='$return_link'><button><i class='fa fa-home'></i> $return_label</button></a>
            </div>
        </body>
        </html>";

        mysqli_stmt_close($stmt);
    } else {
        echo "<h2>Failed to prepare SQL statement.</h2>";
    }

    mysqli_close($dbc);
} else {
    echo "Invalid request.";
}
?>
