<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Contact Us - SKY HIGH Airlines</title>
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(rgba(0,0,0,0.55),rgba(0,0,0,0.55)),
                  url('images/customer_bg_plane.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #222;
      min-height: 100vh;
    }
    ul.navbar {
      list-style: none;
      margin: 0;
      padding: 10px 0;
      background: #003366;
      text-align: center;
      border-radius: 0 0 12px 12px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    ul.navbar li { display: inline-block; margin: 0 8px; }
    ul.navbar li a {
      color: #fff;
      text-decoration: none;
      padding: 10px 16px;
      border-radius: 6px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    ul.navbar li a:hover {
      background: #ff6600;
      color: #fff;
      box-shadow: 0 4px 12px rgba(255,102,0,0.3);
      transform: translateY(-2px);
    }
    h2.page-title {
      text-align: center;
      margin: 30px auto 10px;
      color: #fff;
      text-shadow: 0 2px 6px rgba(0,0,0,0.5);
    }
    .contact-care-flex {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 25px;
      max-width: 900px;
      margin: 30px auto;
      padding: 0 20px;
    }
    .contact-section {
      background: #fff;
      border-radius: 16px;
      padding: 30px 25px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
      text-align: center;
      flex: 1 1 350px;
    }
    .contact-section h2 { color: #003366; margin-top: 0; }
    .contact-form input, .contact-form textarea {
      border: 1.5px solid #003366;
      border-radius: 6px;
      padding: 8px 12px;
      font-size: 0.95rem;
      font-family: inherit;
    }
    .contact-form button {
      background-color: #003366;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 10px 30px;
      cursor: pointer;
      font-weight: 600;
      transition: 0.3s;
    }
    .contact-form button:hover {
      background: #ff6600;
      box-shadow: 0 4px 12px rgba(255,102,0,0.25);
    }
  </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body class="customer-homepage">
  <ul class="navbar">
    <li><a href="customer_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
    <li><a href="customer_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
    <li><a href="customer_contact_us.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
    <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
  </ul>

  <h2 class="page-title">Contact Us</h2>

  <div class="contact-care-flex">
    <div class="contact-section">
      <h2>Send us a message</h2>
      <p>If you have any questions or inquiries, feel free to reach out to us using the form below.</p>
      <form action="contact_form_submit.php" method="post" class="contact-form" style="display:flex; flex-direction:column; align-items:center; gap:16px; max-width:400px; margin:0 auto;">
        <input type="text" name="name" placeholder="Your Name" required style="width:100%; max-width:400px;" <?php echo isset($_SESSION['login_user']) ? 'value="'.htmlspecialchars($_SESSION['login_user']).'"' : ''; ?>>
        <input type="email" name="email" placeholder="Your Email" required style="width:100%; max-width:400px;">
        <textarea name="message" placeholder="Your Message" rows="5" required style="width:100%; max-width:400px;"></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>

    <section class="contact-section">
      <h2>Customer Care Details</h2>
      <p><strong>Contact Number:</strong> +91-859-130-7233</p>
      <p><strong>Email ID:</strong> skyhighairline0@gmail.com</p>
    </section>
  </div>
</body>
</html>
