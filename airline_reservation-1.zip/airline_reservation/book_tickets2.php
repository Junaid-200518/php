<?php
session_start();
?>
<html>
<head>
    <title>Enter Travel/Ticket Details</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f7fc;
            margin: 0;
            padding: 0;
        }
        .logo {
            width: 100px;
            margin: 20px;
        }
        #title {
            text-align: center;
            color: #030337;
            font-size: 36px;
            margin-top: -20px;
        }
        ul {
            list-style-type: none;
            background: #030337;
            overflow: hidden;
            padding: 0;
            margin: 0;
        }
        ul li {
            float: left;
        }
        ul li a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 14px 20px;
        }
        ul li a:hover {
            background: #57578a;
        }

        h2 {
            text-align: center;
            color: #030337;
            margin-top: 30px;
        }
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            margin: 30px auto;
            padding: 20px;
            width: 80%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        td {
            padding: 10px;
            vertical-align: middle;
        }
        input, select {
            width: 90%;
            padding: 8px;
            border: 1.5px solid #030337;
            border-radius: 4px;
            font-size: 14px;
        }
        input[type=number] {
            width: 60%;
        }
        input[type=radio] {
            width: auto;
            margin: 0 10px 0 5px;
        }

        hr {
            border: none;
            border-top: 1px solid #ccc;
            margin: 20px 0;
        }

        .submit-btn {
            background-color: #030337;
            color: white;
            padding: 12px 50px;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            display: block;
            margin: 40px auto;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #57578a;
        }

        .section-title {
            font-weight: bold;
            color: #030337;
            margin-top: 20px;
            margin-bottom: 10px;
            text-align: left;
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
    <h1 id="title">SKY HIGH AIRLINES</h1>
    <div>
        <ul>
            <li><a href="home_page.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
            <li><a href="customer_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
            <li><a href="home_page.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
            <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
        </ul>
    </div>

<?php
    if (empty($_POST['no_of_pass']) || empty($_POST['class']) || empty($_POST['flight_no'])) {
        echo "<h3 style='color:red;text-align:center;'>Please go back and select a flight before proceeding.</h3>";
        echo "</body></html>";
        exit;
    }
    $no_of_adult=(int)$_POST['no_of_pass'];
    $no_of_child=(isset($_POST['no_of_child']) && $_POST['no_of_child'] !== '') ? (int)$_POST['no_of_child'] : 0;
    $no_of_pass=$no_of_adult+$no_of_child; // total passengers (adults + children), matches original meaning of no_of_pass
    $class=strtolower($_POST['class']);
    $count=1;
    $flight_no = isset($_POST['flight_no']) ? $_POST['flight_no'] : '';
    if ($flight_no) {
        $_SESSION['flight_no'] = $flight_no;
    }
    if ($class) {
        $_SESSION['class'] = $class;
    }
    $journey_date = isset($_POST['journey_date']) ? $_POST['journey_date'] : '';
    if ($journey_date) {
    $_SESSION['journey_date'] = $journey_date;
    }
    if ($no_of_pass) {
        $_SESSION['no_of_pass'] = $no_of_pass; 
    }
    $_SESSION['no_of_child'] = $no_of_child;

    echo "<h2>ADD PASSENGERS DETAILS</h2>";
    if ($no_of_child > 0) {
        echo "<p style='text-align:center;color:#0056b3;font-weight:bold;'>Children below 12 years travel at 50% of the ticket price.</p>";
    }
    echo "<form action=\"add_ticket_details_form_handler.php\" method=\"POST\">";
    echo "<div class='card'>";
    while($count<=$no_of_pass)
    {
        $is_child = ($count > $no_of_adult);
        $label = $is_child ? "Passenger $count Details (Child, below 12 years)" : "Passenger $count Details (Adult)";
        $age_attrs = $is_child ? "min='0' max='11'" : "min='12'";
        echo "<div class='section-title'>$label</div>";
        echo "<table>";
        echo "<tr>
                <td>Passenger's Name</td>
                <td>Passenger's Age</td>
                <td>Passenger's Gender</td>
                <td>Passenger's Inflight Meal</td>
                <td>Frequent Flier No. (optional)</td>
              </tr>";
        echo "<tr>";
        echo "<td><input type=\"text\" name=\"pass_name[]\" placeholder='Full Name' required></td>";
        echo "<td><input type=\"number\" name=\"pass_age[]\" $age_attrs placeholder='Age' required></td>";
        echo "<td>
                <select name=\"pass_gender[]\">
                    <option value=\"male\">Male</option>
                    <option value=\"female\">Female</option>
                    <option value=\"other\">Other</option>
                </select>
              </td>";
        echo "<td>
                <select name=\"pass_meal[]\">
                    <option value=\"yes\">Yes</option>
                    <option value=\"no\">No</option>
                </select>
              </td>";
        echo "<td><input type=\"text\" name=\"pass_ff_id[]\" placeholder='Leave blank if none'></td>";
        echo "</tr>";
        echo "</table>";
        echo "<hr>";
        $count=$count+1;
    }
    echo "</div>";

    echo "<h2>ENTER TRAVEL DETAILS</h2>";
    echo "<div class='card'>";
    echo "<table>";
    echo "<tr>
            <td>Do you want access to our Premium Lounge?</td>
            <td>Do you want to opt for Priority Checkin?</td>
          </tr>";
    echo "<tr>
            <td>Yes <input type='radio' name='lounge_access' value='yes' checked/> No <input type='radio' name='lounge_access' value='no'/></td>
            <td>Yes <input type='radio' name='priority_checkin' value='yes' checked/> No <input type='radio' name='priority_checkin' value='no'/></td>
          </tr>";
    echo "</table>";
    echo "</div>";
    echo "<input type=\"hidden\" name=\"no_of_pass\" value=\"".$no_of_pass."\">";
    echo "<input type=\"hidden\" name=\"class\" value=\"".$class."\">";
    echo "<input type=\"hidden\" name=\"journey_date\" value=\"".$journey_date."\">";
    if ($flight_no) {
        echo "<input type=\"hidden\" name=\"flight_no\" value=\"".$flight_no."\">";
    }
    echo "<input type=\"submit\" class='submit-btn' value=\"Submit Travel/Ticket Details\" name=\"Submit\">";
    echo "</form>";
    
?>
</body>
</html>
