<?php
session_start();
require_once('Database Connection file/mysqli_connect.php');

if (!isset($_GET['pnr'])) {
    echo '<div style="color:red;text-align:center;margin-top:40px;font-size:1.3rem;">
            No ticket selected.<br>
            <a href="view_booked_tickets.php" style="color:#ff6600;">Go Back</a>
          </div>';
    exit;
}

$pnr = $_GET['pnr'];

/* === Ticket details with from/destination === */
$query = "SELECT td.pnr, td.date_of_reservation, td.flight_no, fd.from_city, fd.to_city, fd.departure_time, td.journey_date, td.class, td.booking_status, td.no_of_passengers, td.payment_id, td.customer_id 
          FROM Ticket_Details td 
          JOIN flight_details fd ON td.flight_no = fd.flight_no 
          WHERE td.pnr=?";
$stmt = mysqli_prepare($dbc, $query);
mysqli_stmt_bind_param($stmt, "s", $pnr);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result(
    $stmt,
    $pnr,
    $date_of_reservation,
    $flight_no,
    $from_city,
    $to_city,
    $departure_time,
    $journey_date,
    $class,
    $booking_status,
    $no_of_passengers,
    $payment_id,
    $customer_id
);

if (!mysqli_stmt_fetch($stmt)) {
    echo '<div style="color:red;text-align:center;margin-top:40px;font-size:1.3rem;">
            Ticket not found.<br>
            <a href="view_booked_tickets.php" style="color:#ff6600;">Go Back</a>
          </div>';
    exit;
}
mysqli_stmt_close($stmt);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ticket Details</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body { font-family: Arial, Helvetica, sans-serif; background: #f4f7fc; margin: 0; padding: 0; }
        .ticket-softcopy {
            max-width: 600px;
            margin: 40px auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.13);
            padding: 32px 28px 24px;
            text-align: left;
            position: relative;
        }
        .ticket-softcopy h2 {
            text-align: center;
            color: #003366;
            margin-bottom: 18px;
            font-size: 1.6rem;
        }
        .ticket-info {
            font-size: 1.1rem;
            margin-bottom: 10px;
        }
        .ticket-label {
            font-weight: bold;
            color: #003366;
            width: 180px;
            display: inline-block;
        }
        .ticket-value {
            color: #222;
        }
        .ticket-barcode {
            text-align: center;
            margin-top: 30px;
        }
        .ticket-barcode img {
            width: 220px;
            height: 40px;
        }
        .ticket-footer {
            text-align: center;
            margin-top: 18px;
            color: #888;
            font-size: 0.95rem;
        }
        .ticket-logo {
            display: block;
            margin: 0 auto 18px auto;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            background: #fff;
        }
        table.passenger-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        table.passenger-table th, table.passenger-table td {
            padding: 6px 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table.passenger-table th {
            background: #f4f7fc;
            color: #003366;
            font-weight: bold;
        }
        .ticket-actions {
            text-align: center;
            margin-top: 18px;
        }
        .print-btn {
            display: inline-block;
            padding: 10px 24px;
            background: #ff6600;
            color: #fff;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            font-size: 1.1rem;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0,0,0,0.10);
            margin-top: 18px;
            margin-right: 10px;
        }
        .print-btn:hover {
            background: #e65c00;
        }
        @media print {
            body { background: #fff !important; }
            .ticket-actions,
            .ticket-footer a,
            ul.navbar,
            .no-print {
                display: none !important;
            }
            .ticket-softcopy {
                box-shadow: none !important;
                margin: 0 auto !important;
            }
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
<div class="ticket-softcopy">
    <img class="ticket-logo" src="images/IMG_20250921_131245.jpg"/> 
    <h2>SKY HIGH AIRLINES - E-Ticket</h2>

    <div class="ticket-info"><span class="ticket-label">PNR:</span> <span class="ticket-value"><?php echo htmlspecialchars($pnr); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Date of Reservation:</span> <span class="ticket-value"><?php echo htmlspecialchars($date_of_reservation); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Flight No.:</span> <span class="ticket-value"><?php echo htmlspecialchars($flight_no); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">From:</span> <span class="ticket-value"><?php echo htmlspecialchars($from_city); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Destination:</span> <span class="ticket-value"><?php echo htmlspecialchars($to_city); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Departure Time:</span> <span class="ticket-value"><?php echo htmlspecialchars($departure_time); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Journey Date:</span> <span class="ticket-value"><?php echo htmlspecialchars($journey_date); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">No. of Passengers:</span> <span class="ticket-value"><?php echo htmlspecialchars($no_of_passengers); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Class:</span> <span class="ticket-value"><?php echo ucfirst(htmlspecialchars($class)); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Booking Status:</span> <span class="ticket-value"><?php echo htmlspecialchars($booking_status); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Payment ID:</span> <span class="ticket-value"><?php echo htmlspecialchars($payment_id); ?></span></div>
    <div class="ticket-info"><span class="ticket-label">Customer ID:</span> <span class="ticket-value"><?php echo htmlspecialchars($customer_id); ?></span></div>

    <div class="ticket-footer">
    This is a computer generated ticket and does not require physical signature.<br>
    Please carry a valid ID proof for verification at the airport.
    </div>

    <div class="ticket-actions">
        <button type="button" class="print-btn" onclick="window.print()"><i class="fa fa-print"></i> Print Ticket</button>
        <a href="customer_homepage.php" style="display:inline-block;padding:10px 24px;background:#030337;color:#fff;border-radius:6px;text-decoration:none;font-size:1.1rem;box-shadow:0 2px 8px rgba(0,0,0,0.10);margin-top:18px;">&larr; Dashboard</a>
    </div>
</div>
</body>
</html>
