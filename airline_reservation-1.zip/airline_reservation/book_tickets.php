<?php
	session_start();
?>
<html>
<head>
	<title>View Available Flights</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		/* Global */
		body {
			font-family: 'Segoe UI', sans-serif;
			margin: 0;
			background: linear-gradient(135deg, #e0f7fa, #f1f8ff);
			min-height: 100vh;
			color: #333;
		}

		.logo {
			width: 120px;
			margin: 20px auto;
			display: block;
			border-radius: 12px;
			box-shadow: 0 4px 8px rgba(0,0,0,0.2);
		}

		#title {
			text-align: center;
			color: #0056b3;
			font-size: 2rem;
			margin-bottom: 10px;
		}

		/* Navbar */
		ul {
			list-style: none;
			margin: 0;
			padding: 0;
			background: #0056b3;
			display: flex;
			justify-content: center;
			flex-wrap: wrap;
		}

		ul li {
			margin: 0;
		}

		ul li a {
			display: block;
			color: #fff;
			padding: 14px 25px;
			text-decoration: none;
			font-size: 16px;
			transition: background 0.3s ease;
		}

		ul li a:hover {
			background: #003f80;
		}

		/* Form Container */
		form {
			max-width: 800px;
			margin: 40px auto;
			background: #fff;
			padding: 30px 40px;
			border-radius: 12px;
			box-shadow: 0 8px 18px rgba(0,0,0,0.1);
		}

		form h2 {
			text-align: center;
			color: #0056b3;
			margin-bottom: 25px;
		}

		table {
			width: 100%;
		}

		td.fix_table {
			padding: 10px;
			font-weight: bold;
		}

		input, select {
			width: 100%;
			border: 1.5px solid #0056b3;
			border-radius: 6px;
			padding: 10px 12px;
			font-size: 15px;
			margin-top: 5px;
			transition: border-color 0.3s ease, box-shadow 0.3s ease;
		}

		input:focus, select:focus {
			outline: none;
			border-color: #003f80;
			box-shadow: 0 0 4px #80bdff;
		}

		input[type=submit] {
			background: linear-gradient(135deg, #0056b3, #003f80);
			color: white;
			border: none;
			font-weight: bold;
			cursor: pointer;
			width: 100%;
			padding: 14px;
			margin-top: 20px;
			transition: background 0.3s ease;
		}

		input[type=submit]:hover {
			background: linear-gradient(135deg, #003f80, #00295d);
		}

		@media (max-width: 600px) {
			form {
				padding: 20px;
			}
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
	<h1 id="title">SKY HIGH AIRLINES</h1>

	<div>
		<ul>
			<li><a href="customer_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="customer_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<form action="view_flights_form_handler.php" method="post">
		<h2><i class="fa fa-plane"></i> Search for Available Flights</h2>
		<table>
			<tr>
				<td class="fix_table">From Location</td>
				<td class="fix_table">Destination Location</td>
			</tr>
			<tr>
				<td class="fix_table">
					<input list="origins" name="origin" placeholder="From" required>
					<datalist id="origins">
						<option value="Bangalore">
						<option value="Delhi">
						<option value="Kolkata">
					</datalist>
				</td>
				<td class="fix_table">
					<input list="destinations" name="destination" placeholder="To" required>
					<datalist id="destinations">
						<option value="Mumbai">
						<option value="Mysore">
						<option value="Mangalore">
						<option value="Chennai">
						<option value="Hyderabad">
					</datalist>
				</td>
			</tr>
		</table>
		<br>
		<table>
			<tr>
				<td class="fix_table">Departure Date</td>
				<td class="fix_table">No. of Passengers (Adults)</td>
				<td class="fix_table">No. of Children (below 12 yrs)</td>
			</tr>
			<tr>
				<td class="fix_table">
					<input type="date" name="dep_date"
						min="<?php echo date('Y-m-d'); ?>"
						max="<?php $max_date=date_create(date('Y-m-d'));date_add($max_date,date_interval_create_from_date_string("90 days"));echo date_format($max_date,"Y-m-d");?>" required>
				</td>
				<td class="fix_table">
					<input type="number" name="no_of_pass" min="1" placeholder="Eg. 5" required>
				</td>
				<td class="fix_table">
					<input type="number" name="no_of_child" min="0" value="0" placeholder="Eg. 1">
					<small style="font-weight:normal;display:block;">Children travel at 50% of the ticket price</small>
				</td>
			</tr>
		</table>
		<br>
		<table>
			<tr>
				<td class="fix_table">Class</td>
			</tr>
			<tr>
				<td class="fix_table">
					<select name="class">
						<option value="Economy">Economy</option>
						<option value="Business">Business</option>
					</select>
				</td>
			</tr>
		</table>
		<input type="submit" value="Search for Available Flights" name="Search">
	</form>
</body>
</html>
