<?php
session_start();
?>
<html>
<head>
    <title>Enter Payment Details</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {font-family: Arial, Helvetica, sans-serif;background: #f4f7fc;margin: 0;padding: 0;}
        .logo {width: 100px;margin: 20px;}
        #title {text-align: center;color: #030337;font-size: 36px;margin-top: -20px;}
        ul {list-style-type: none;background: #030337;overflow: hidden;padding: 0;margin: 0;}
        ul li {float: left;}
        ul li a {display: block;color: white;text-decoration: none;padding: 14px 20px;}
        ul li a:hover {background: #57578a;}
        h2 {text-align: center;color: #030337;margin-top: 30px;}
        .card {background: white;border-radius: 8px;box-shadow: 0 4px 8px rgba(0,0,0,0.1);margin: 30px auto;padding: 20px;width: 80%;}
        table {width: 100%;border-collapse: collapse;}
        td {padding: 8px;vertical-align: middle;}
        input[type=radio] {margin: 0 10px 0 5px;}
        .submit-btn {background-color: #030337;color: white;padding: 12px 50px;font-size: 16px;border: none;border-radius: 6px;display: block;margin: 40px auto;cursor: pointer;}
        .submit-btn:hover {background-color: #57578a;}
        .total-row td {font-weight: bold;color: #030337;border-top: 1px solid #ccc;padding-top: 10px;}
        .info-text {margin-left: 20px;font-size: 14px;}
        .paymode-table td {width: 33%;}
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
<h1 id="title">SKY HIGH AIRLINES</h1>
<div>
    <ul>
        <li><a href="home_page.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
        <li><a href="customer_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
        <li><a href="home_page.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
        <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
    </ul>
</div>

<h2>ENTER THE PAYMENT DETAILS</h2>

<form action="payment_details_form_handler.php" method="post">
<div class="card">
<h3><u>Payment Summary</u></h3>
<?php
$flight_no    = $_SESSION['flight_no'];
$classSession = $_SESSION['class'];
$journey_date = $_SESSION['journey_date'];
$no_of_pass   = $_SESSION['no_of_pass'];
$total_no_of_meals = $_SESSION['total_no_of_meals'];
$no_of_child  = isset($_SESSION['no_of_child']) ? (int)$_SESSION['no_of_child'] : 0;
$no_of_adult  = $no_of_pass - $no_of_child;

$payment_id = rand(100000000,999999999);
$pnr        = $_SESSION['pnr'];
$_SESSION['payment_id']  = $payment_id;
$payment_date            = date('Y-m-d');
$_SESSION['payment_date']= $payment_date;

require_once('Database Connection file/mysqli_connect.php');

// initialise ticket_price to avoid warning
$ticket_price = 0;
// normalise class to lowercase
$class = strtolower($classSession);

// prepare statement depending on class
if ($class == 'economy') {
    $query = "SELECT price_economy FROM Flight_Details WHERE flight_no=? AND departure_date=?";
    $stmt = mysqli_prepare($dbc,$query);
    mysqli_stmt_bind_param($stmt,"ss",$flight_no,$journey_date);
} else {
    $query = "SELECT price_business FROM Flight_Details WHERE flight_no=? AND departure_date=?";
    $stmt = mysqli_prepare($dbc,$query);
    mysqli_stmt_bind_param($stmt,"ss",$flight_no,$journey_date);
}

mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt,$ticket_price);

if (!mysqli_stmt_fetch($stmt)) {
    echo "<p style='color:red;font-weight:bold;'>No matching flight found for $flight_no on $journey_date</p>";
    $ticket_price = 0;
}

mysqli_stmt_close($stmt);
mysqli_close($dbc);

// now compute totals
// Children (below 12 years) are charged 50% of the adult ticket price
$total_ticket_price         = ($no_of_adult * $ticket_price) + ($no_of_child * $ticket_price);
$total_child_discount       = $no_of_child * $ticket_price * 0.5;
$total_meal_price           = 250 * $total_no_of_meals;
$total_priority_checkin_fee = ($_SESSION['priority_checkin']=='yes') ? 200*$no_of_pass : 0;
$total_lounge_access_fee    = ($_SESSION['lounge_access']=='yes') ? 300*$no_of_pass : 0;
$total_discount             = $total_child_discount;
$total_amount               = $total_ticket_price + $total_meal_price + $total_priority_checkin_fee + $total_lounge_access_fee - $total_discount;
$_SESSION['total_amount']   = $total_amount;

// output table
echo "<table>";
echo "<tr><td>Base Fare (Fees & Taxes included):</td><td>&#x20b9; ".$total_ticket_price."</td></tr>";
if ($no_of_child > 0) {
    echo "<tr><td>Child Fare Discount (".$no_of_child." child @ 50% off):</td><td>- &#x20b9; ".$total_child_discount."</td></tr>";
}
echo "<tr><td>Meal Combo Charges:</td><td>&#x20b9; ".$total_meal_price."</td></tr>";
echo "<tr><td>Priority Checkin Fees:</td><td>&#x20b9; ".$total_priority_checkin_fee."</td></tr>";
echo "<tr><td>Lounge Access Fees:</td><td>&#x20b9; ".$total_lounge_access_fee."</td></tr>";
echo "<tr class='total-row'><td>Total:</td><td>&#x20b9; ".$total_amount."</td></tr>";
echo "</table>";

echo "<p class='info-text'>Your Payment/Transaction ID is <strong>".$payment_id."</strong>. Please note it down for future reference.</p>";
?>
</div>

<div class="card">
<h3>Select Payment Mode</h3>
<table class="paymode-table">
<tr>
<td><i class="fa fa-credit-card"></i> Credit Card <input type="radio" name="payment_mode" value="credit card" checked></td>
<td><i class="fa fa-credit-card-alt"></i> Debit Card <input type="radio" name="payment_mode" value="debit card"></td>
<td><i class="fa fa-desktop"></i> Net Banking <input type="radio" name="payment_mode" value="net banking"></td>
</tr>
</table>
</div>

<input type="submit" class="submit-btn" value="Pay Now" name="Pay_Now">
</form>
</body>
</html>
