<?php
require_once('Database Connection file/mysqli_connect.php');
session_start();
$message = "";
$step = 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['request_otp'])) {
        $email = trim($_POST['email']);
        $query = "SELECT customer_id FROM customer WHERE email=?";
        $stmt = mysqli_prepare($dbc, $query);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $customer_id);
        if (mysqli_stmt_fetch($stmt)) {
            $otp = rand(100000, 999999);
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_otp'] = $otp;
            $_SESSION['reset_customer_id'] = $customer_id;
            // For testing: Show OTP on the page instead of sending email
            $message = "OTP for testing: <strong>$otp</strong> (would be sent to your email in production).";
            $step = 2;
        } else {
            $message = "Email not found.";
        }
        mysqli_stmt_close($stmt);
    } elseif (isset($_POST['verify_otp'])) {
        $otp = trim($_POST['otp']);
        $new_password = trim($_POST['new_password']);
        if (!isset($_SESSION['reset_otp']) || !isset($_SESSION['reset_customer_id'])) {
            $message = "Session expired. Please try again.";
        } elseif ($otp != $_SESSION['reset_otp']) {
            $message = "Invalid OTP.";
            $step = 2;
        } elseif (strlen($new_password) > 6) {
            $message = "Password must be at most 6 characters.";
            $step = 2;
        } else {
            $query = "UPDATE customer SET pwd=? WHERE customer_id=?";
            $stmt = mysqli_prepare($dbc, $query);
            mysqli_stmt_bind_param($stmt, "ss", $new_password, $_SESSION['reset_customer_id']);
            mysqli_stmt_execute($stmt);
            if (mysqli_stmt_affected_rows($stmt) > 0) {
                $message = "Password reset successful!";
                unset($_SESSION['reset_otp'], $_SESSION['reset_email'], $_SESSION['reset_customer_id']);
                $step = 3;
            } else {
                $message = "Password reset failed.";
                $step = 2;
            }
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($dbc);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <style>
        .reset-box { max-width: 400px; margin: 60px auto; background: #fff; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,0.10); padding: 32px; }
        .reset-box h2 { text-align:center; color:#003366; margin-bottom:18px; }
        .reset-box input { width:100%; margin-bottom:14px; padding:10px; border-radius:6px; border:1.5px solid #003366; }
        .reset-box button { width:100%; }
        .message { text-align:center; color:#ff6600; margin-bottom:10px; }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <div class="reset-box">
        <h2>Reset Password</h2>
        <?php if($message): ?><div class="message"><?php echo $message; ?></div><?php endif; ?>
        <?php if($step === 1): ?>
        <form method="post">
            <input type="email" name="email" placeholder="Enter Registered Email" required>
            <button type="submit" name="request_otp">Send OTP</button>
        </form>
        <?php elseif($step === 2): ?>
        <form method="post">
            <input type="text" name="otp" maxlength="6" placeholder="Enter OTP" required>
            <input type="password" name="new_password" maxlength="6" placeholder="New Password (max 6 chars)" required>
            <button type="submit" name="verify_otp">Reset Password</button>
        </form>
        <?php elseif($step === 3): ?>
        <div class="message">You may now <a href="login_page.php">login</a> with your new password.</div>
        <?php endif; ?>
        <div style="text-align:center; margin-top:10px;">
            <a href="login_page.php">Back to Login</a>
        </div>
    </div>
</body>
</html>
