<html>
<head>
    <title>Registration Successful - SKY HIGH Airlines</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #e6f0ff; /* light blue background */
            margin: 0;
            padding: 0;
            color: #030337;
        }
        .logo {
            display: block;
            margin: 20px auto;
            max-width: 150px;
            border-radius: 10px;
        }
        #title {
            text-align: center;
            color: #003366;
            margin-bottom: 20px;
        }
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            overflow: hidden;
            background-color: #003366;
        }
        ul li {
            float: left;
        }
        ul li a {
            display: block;
            color: white;
            text-align: center;
            padding: 12px 20px;
            text-decoration: none;
            font-weight: bold;
        }
        ul li a:hover {
            background-color: #6699ff;
        }
        .success-message {
            background-color: #ffffff;
            width: 50%;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            color: #003366;
        }
        .success-message i {
            font-size: 50px;
            color: #28a745;
            margin-bottom: 15px;
        }
        .success-message h3 {
            font-size: 22px;
            margin-bottom: 20px;
        }
        .success-message a {
            display: inline-block;
            text-decoration: none;
            background-color: #003366;
            color: white;
            padding: 10px 30px;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }
        .success-message a:hover {
            background-color: #6699ff;
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
    <h1 id="title">SKY HIGH AIRLINES</h1>

    <ul>
        <li><a href="home_page.php"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="login_page.php"><i class="fa fa-ticket"></i> Book Tickets</a></li>
        <li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
        <li><a href="login_page.php"><i class="fa fa-sign-in"></i> Login</a></li>
    </ul>

    <div class="success-message">
        <i class="fa fa-check-circle"></i>
        <h3>New user successfully registered!</h3>
        <p>Login into your account to book tickets.</p>
        <a href="login_page.php">Login Now</a>
    </div>
</body>
</html>
