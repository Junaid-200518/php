<?php
	session_start();
?>
<html>
<head>
	<title>View Booked Tickets</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		body {
			margin: 0;
			font-family: 'Segoe UI', sans-serif;
			background: #e6f0ff; /* Light blue background */
			color: #030337;
		}
		.logo {
			height: 70px;
			margin: 15px 20px;
		}
		#title {
			display: inline-block;
			font-size: 28px;
			font-weight: bold;
			color: #030337;
			vertical-align: middle;
		}
		ul {
			list-style-type: none;
			background-color: #030337;
			padding: 0;
			margin: 0;
			overflow: hidden;
			border-radius: 8px;
		}
		ul li {
			float: left;
		}
		ul li a {
			display: block;
			color: #fff;
			padding: 14px 20px;
			text-decoration: none;
			transition: background 0.3s ease;
		}
		ul li a:hover {
			background: #6699ff;
			color: white;
		}
		h2 {
			text-align: center;
			margin-top: 40px;
			font-size: 30px;
			color: #030337;
		}
		form {
			background: #fff;
			max-width: 600px;
			margin: 40px auto;
			padding: 30px;
			border-radius: 12px;
			box-shadow: 0 8px 20px rgba(0,0,0,0.15);
		}
		table {
			width: 100%;
			margin-top: 20px;
		}
		.fix_table {
			padding: 10px;
			font-weight: 600;
			color: #030337;
		}
		input[type=text], input[type=date] {
			width: 100%;
			border: 1.5px solid #030337;
			border-radius: 6px;
			padding: 8px;
			font-size: 16px;
			outline: none;
			transition: 0.3s;
		}
		input[type=text]:focus, input[type=date]:focus {
			border-color: #6699ff;
			box-shadow: 0 0 8px rgba(102,153,255,0.5);
		}
		input[type=submit] {
			background-color: #030337;
			color: white;
			border-radius: 6px;
			padding: 10px 50px;
			margin-top: 20px;
			font-size: 16px;
			cursor: pointer;
			transition: background 0.3s, transform 0.3s;
			display: block;
			margin-left: auto;
			margin-right: auto;
		}
		input[type=submit]:hover {
			background-color: #6699ff;
			transform: translateY(-2px);
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<div style="display:flex; align-items:center; padding:10px 20px;">
		<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
		<h1 id="title">SKY HIGH AIRLINES</h1>
	</div>

	<div>
		<ul>
			<li><a href="admin_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="admin_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<form action="admin_view_booked_tickets_form_handler.php" method="post">
		<h2>View List of Booked Tickets for a Flight</h2>
		<table>
			<tr>
				<td class="fix_table">Enter Flight No.</td>
				<td class="fix_table">Enter Departure Date</td>
			</tr>
			<tr>
				<td><input type="text" name="flight_no" placeholder="e.g., SK123" required></td>
				<td><input type="date" name="departure_date" required></td>
			</tr>
		</table>
		<input type="submit" value="Submit" name="Submit">
	</form>
</body>
</html>
