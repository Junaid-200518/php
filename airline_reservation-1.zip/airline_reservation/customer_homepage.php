<?php 
session_start();
// if($_SESSION['login_user']==null){
//     header('location:home_page.php');
//     exit;
// }
require_once('Database Connection file/mysqli_connect.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Welcome Customer</title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(rgba(0,0,0,0.55),rgba(0,0,0,0.55)),
                  url('images/customer_bg_plane.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #222;
      min-height: 100vh;
    }
    .logo {
      display: block;
      margin: 20px auto 10px;
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      box-shadow: 0 4px 15px rgba(0,0,0,0.15);
      background: #fff;
    }
    #title {
      text-align: center;
      font-size: 2rem;
      text-shadow: 0 2px 6px rgba(0,0,0,0.5);
      margin-bottom: 10px;
      color: #fff;
    }

    /* Navbar - matches home_page.php exactly (same class, colors, font, hover effect) */
    ul.navbar {
      list-style: none;
      margin: 0;
      padding: 10px 0;
      background: #003366;
      text-align: center;
      border-radius: 0 0 12px 12px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    ul.navbar li {
      display: inline-block;
      margin: 0 8px;
    }
    ul.navbar li a {
      color: #fff;
      text-decoration: none;
      padding: 10px 16px;
      border-radius: 6px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    ul.navbar li a:hover {
      background: #ff6600;
      color: #fff;
      box-shadow: 0 4px 12px rgba(255,102,0,0.3);
      transform: translateY(-2px);
    }

    .welcome-header {
      text-align: center;
      margin: 30px auto 10px;
      color: #fff;
      text-shadow: 0 2px 6px rgba(0,0,0,0.4);
    }
    .welcome-header h2 { font-size: 1.8rem; margin-bottom: 6px; }
    .welcome-header h4 { font-weight: 400; font-size: 1rem; }
    .dashboard {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }
    @media (max-width: 900px) {
      .dashboard { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 500px) {
      .dashboard { grid-template-columns: 1fr; }
    }
    .dash-card {
      background: #fff;
      border-radius: 16px;
      padding: 25px 20px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
      text-align: center;
      transition: transform 0.3s, box-shadow 0.3s;
    }
    .dash-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 28px rgba(0,0,0,0.15);
    }
    .dash-card a {
      text-decoration: none;
      color: #003366;
      font-size: 1.1rem;
      font-weight: 600;
    }
    .dash-card i {
      font-size: 2rem;
      margin-bottom: 12px;
      color: #ff6600;
    }
    input, select {
      border: 1.5px solid #003366;
      border-radius: 6px;
      padding: 8px 12px;
      font-size: 0.95rem;
    }
    input[type=submit] {
      background-color: #003366;
      color: white;
      border-radius: 6px;
      padding: 10px 45px;
      margin-top: 10px;
      cursor: pointer;
      font-weight: 600;
      transition: 0.3s;
    }
    input[type=submit]:hover {
      background: #ff6600;
      box-shadow: 0 4px 12px rgba(255,102,0,0.25);
    }
    @media(max-width:600px){
      .welcome-header h2{font-size:1.4rem;}
    }
    table {
      background:#fff; margin:30px auto; border-collapse: collapse;
    }
    table th, table td {padding:8px 12px; border:1px solid #ccc;}
    table th{background:#003366; color:#fff;}
  </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body class="customer-homepage">

  <!-- Logo & Title -->
  <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
  <h1 id="title">SKY HIGH AIRLINES</h1>

  <!-- Navbar -->
  <ul class="navbar">
    <li><a href="customer_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
    <li><a href="customer_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
    <li><a href="customer_contact_us.php"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
    <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
  </ul>

  <!-- Welcome message -->
  <div class="welcome-header">
    <?php
      echo "<h2>Welcome ".$_SESSION['login_user']."</h2>";
      $query="SELECT count(*),frequent_flier_no,mileage 
              FROM Frequent_Flier_Details WHERE customer_id=?";
      $stmt=mysqli_prepare($dbc,$query);
      mysqli_stmt_bind_param($stmt,"s",$_SESSION['login_user']);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_bind_result($stmt,$cnt,$frequent_flier_no,$mileage);
      mysqli_stmt_fetch($stmt);
      if($cnt==1)
      {
        echo "<h4>Frequent Flier No.: ".$frequent_flier_no." &nbsp;&nbsp; | &nbsp;&nbsp; Mileage: ".$mileage." points</h4>";
      }
      mysqli_stmt_close($stmt);
    ?>
  </div>

  <!-- Dashboard Links -->
  <div class="dashboard">
    <div class="dash-card">
      <i class="fa fa-plane"></i><br>
      <a href="book_tickets.php">Book Flight Tickets</a>
    </div>
    <div class="dash-card">
      <i class="fa fa-ticket"></i><br>
      <a href="view_booked_tickets.php">View Booked Flight Tickets</a>
    </div>
    <div class="dash-card">
      <i class="fa fa-times-circle"></i><br>
      <a href="cancel_booked_tickets.php">Cancel Booked Flight Tickets</a>
    </div>
    <div class="dash-card">
      <i class="fa fa-envelope-o"></i><br>
      <a href="customer_view_messages.php">My Messages &amp; Replies</a>
    </div>
  </div>

  <!-- Available Flights List -->
  <?php
// only upcoming flights
$query = "SELECT * 
          FROM Flight_Details 
          WHERE departure_date >= CURDATE() 
          ORDER BY departure_date, departure_time";
$result = mysqli_query($dbc, $query);
?>
  <h2 style="text-align:center;color:#fff;">Available Flights</h2>
  <table>
    <tr>
        <th>Flight No</th>
        <th>From</th>
        <th>Destination</th>
        <th>Departure Date</th>
        <th>Departure Time</th>
        <th>Arrival Date</th>
        <th>Arrival Time</th>
        <th>Duration</th>
        <th>Economy Price</th>
        <th>Business Price</th>
        <th>Action</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo $row['flight_no']; ?></td>
        <td><?php echo $row['from_city']; ?></td>
        <td><?php echo $row['to_city']; ?></td>
        <td><?php echo $row['departure_date']; ?></td>
        <td><?php echo $row['departure_time']; ?></td>
        <td><?php echo $row['arrival_date']; ?></td>
        <td><?php echo $row['arrival_time']; ?></td>
        
        <td><?php 
        $dep = new DateTime($row['departure_date'].' '.$row['departure_time']);
        $arr = new DateTime($row['arrival_date'].' '.$row['arrival_time']);
        $diff = $arr->diff($dep);
        // you can also include days: $diff->d for days difference
        echo $diff->h . 'h ' . $diff->i . 'm';
        ?></td>
        <td><?php echo isset($row['price_economy']) ? '&#x20b9; ' . $row['price_economy'] : 'N/A'; ?></td>
        <td><?php echo isset($row['price_business']) ? '&#x20b9; ' . $row['price_business'] : 'N/A'; ?></td>
        
        <td>
            <form action="book_tickets_3.php" method="POST">
                <input type="hidden" name="flight_no" value="<?php echo $row['flight_no']; ?>">
                <input type="hidden" name="journey_date" value="<?php echo $row['departure_date']; ?>">
                <input type="hidden" name="from_city" value="<?php echo $row['from_city']; ?>">
                <input type="hidden" name="to_city" value="<?php echo $row['to_city']; ?>">
                <input type="hidden" name="departure_time" value="<?php echo $row['departure_time']; ?>">
                <input type="hidden" name="arrival_time" value="<?php echo $row['arrival_time']; ?>">
                <input type="hidden" name="price_economy" value="<?php echo $row['price_economy']; ?>"> 
                <input type="hidden" name="price_business" value="<?php echo $row['price_business']; ?>">  
                <input type="submit" value="Book Flight">
            </form>
        </td>
    </tr>
    <?php } mysqli_close($dbc); ?>
  </table>

</body>
</html>
