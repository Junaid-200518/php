<?php
session_start();
require_once('Database Connection file/mysqli_connect.php');
require_once('contact_messages_setup.php');

ensure_contact_messages_table($dbc);

$action = isset($_POST['action']) ? $_POST['action'] : '';
$message_id = isset($_POST['message_id']) ? (int)$_POST['message_id'] : 0;

if ($message_id > 0 && $action === 'reply') {
    $reply_text = isset($_POST['reply_text']) ? trim($_POST['reply_text']) : '';
    if ($reply_text !== '') {
        $query = "UPDATE contact_messages SET reply = ?, replied_at = NOW() WHERE id = ?";
        $stmt = mysqli_prepare($dbc, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "si", $reply_text, $message_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        } else {
            mysqli_close($dbc);
            die('Could not save the reply. Please check the Contact Us database table. <br><a href="admin_view_messages.php">Back</a>');
        }
    }
} elseif ($message_id > 0 && $action === 'delete') {
    $query = "DELETE FROM contact_messages WHERE id = ?";
    $stmt = mysqli_prepare($dbc, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $message_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    } else {
        mysqli_close($dbc);
        die('Could not delete the message. Please check the Contact Us database table. <br><a href="admin_view_messages.php">Back</a>');
    }
}

mysqli_close($dbc);
header("location: admin_view_messages.php");
exit;
