# FOS (Food Ordering System) - Database Schema Documentation

## Overview
This document contains the database structure for the Food Ordering System application based on extracted information from INSERT, SELECT, UPDATE, and JOIN statements found in the PHP codebase.

---

## Database: `fosdb`

---

## Tables and Field Structure

### 1. **tbluser** (User Accounts)
**Purpose:** Stores user account information for customers

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| ID | INT | Primary Key - User ID | Auto-increment identifier |
| FirstName | VARCHAR | User's first name | String |
| LastName | VARCHAR | User's last name | String |
| Email | VARCHAR | User email address | Unique, for login |
| MobileNumber | VARCHAR | User phone number | Used for login & contact |
| Password | VARCHAR | Encrypted password | Hashed password |
| Coupon | DECIMAL/INT | Discount coupon percentage | Nullable, stores discount % or NULL |

**Key Information:**
- Users can login with Email OR MobileNumber + Password
- Coupon field stores discount percentages applied to orders
- Used in JOINs with tblorderaddresses and tblorders tables

---

### 2. **tblorders** (Order Items/Cart Items)
**Purpose:** Stores individual food items in orders and shopping carts

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| ID | INT | Primary Key - Order Item ID | Auto-increment |
| UserId | INT | Foreign Key - User ID | References tbluser.ID |
| FoodId | INT | Foreign Key - Food Item ID | References tblfood.ID |
| FoodQty | INT | Quantity of food item | Quantity ordered |
| OrderNumber | VARCHAR/INT | Order reference number | Generated on checkout |
| IsOrderPlaced | TINYINT/BOOLEAN | Order status flag | NULL (cart) or 1 (placed) |

**Key Information:**
- Tracks items in user's cart (when IsOrderPlaced is NULL)
- Tracks ordered items (when IsOrderPlaced = 1)
- Linked to tblorderaddresses via OrderNumber
- Used in JOINs with tblfood to get item details

**Example Usage:**
```sql
INSERT INTO tblorders(UserId,FoodId,FoodQty) VALUES('$userid','$foodid','$foodqty')
UPDATE tblorders SET OrderNumber='$orderno',IsOrderPlaced='1' WHERE UserId='$userid' AND IsOrderPlaced IS NULL
```

---

### 3. **tblfood** (Food Items/Products)
**Purpose:** Stores food items/products available for ordering

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| ID | INT | Primary Key - Food Item ID | Auto-increment |
| CategoryName | VARCHAR | Food category name | e.g., "Restaurant", "Home made food" |
| ItemName | VARCHAR | Food item name | e.g., "Aloo Paratha" |
| ItemPrice | DECIMAL | Price per unit | Product price |
| ItemDes | TEXT | Item description | Detailed description |
| ItemQty | INT | Quantity available | Stock quantity |
| Image | VARCHAR | Image filename | Stored in admin/itemimages/ folder |
| restname | VARCHAR | Restaurant name | Optional, for filtering |

**Key Information:**
- Images stored as filenames with MD5 hash + extension
- Used in product detail pages and search functionality
- Can be filtered by CategoryName or restname
- Contains both basic inventory info and descriptive details

---

### 4. **tblcategory** (Food Categories)
**Purpose:** Stores food categories for organization

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| ID | INT | Primary Key - Category ID | Auto-increment |
| CategoryName | VARCHAR | Category name | e.g., "North Indian", "Chinese" |
| Categorytype | VARCHAR | Category type | e.g., "Restaurant" or "Home made food" |

**Key Information:**
- Categories filtered by Categorytype for menu display
- Used to organize food items in tblfood table
- Supports multiple category types for different vendor types

---

### 5. **tblorderaddresses** (Order Delivery Information)
**Purpose:** Stores order details and delivery addresses

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| ID | INT | Primary Key - Order Address ID | Auto-increment |
| UserId | INT | Foreign Key - User ID | References tbluser.ID |
| Ordernumber | VARCHAR/INT | Order reference number | Unique, links to tblorders |
| Flatnobuldngno | VARCHAR | Flat/Building number | Delivery address line 1 |
| StreetName | VARCHAR | Street name | Delivery address line 2 |
| Area | VARCHAR | Area/Locality | Delivery area |
| Landmark | VARCHAR | Landmark | Optional location reference |
| City | VARCHAR | City name | Delivery city |
| OrderTime | DATETIME | Order placement timestamp | Date and time of order |
| OrderFinalStatus | VARCHAR | Order status | Possible values: NULL, "Order Confirmed", "In Packaging", "Order Pickup", "Order Delivered", "Order Cancelled" |

**Key Information:**
- Linked to tbluser and tblorders via foreign keys
- Stores complete delivery address for order fulfillment
- OrderFinalStatus tracks order lifecycle:
  - NULL = Pending confirmation
  - "Order Confirmed" = Confirmed by admin
  - "In Packaging" = Being prepared
  - "Order Pickup" = Ready for pickup
  - "Order Delivered" = Delivered to customer
  - "Order Cancelled" = Order was cancelled

**Example Usage:**
```sql
INSERT INTO tblorderaddresses(UserId,Ordernumber,Flatnobuldngno,StreetName,Area,Landmark,City) 
VALUES('$userid','$orderno','$fnaobno','$street','$area','$lndmark','$city')

UPDATE tblorderaddresses SET OrderFinalStatus='$status' WHERE Ordernumber='$oid'
```

---

### 6. **tblfoodtracking** (Order Status Tracking)
**Purpose:** Maintains history of order status changes and tracking information

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| ID | INT | Primary Key - Tracking ID | Auto-increment (assumed) |
| OrderId | VARCHAR/INT | Order reference number | Links to Ordernumber in tblorderaddresses |
| remark | TEXT | Status update remark/comment | Reason or note for status change |
| status | VARCHAR | Order status at this point | Same values as OrderFinalStatus |
| StatusDate | DATETIME | Timestamp of status update | When status was updated (assumed auto-timestamp) |
| OrderCanclledByUser | TINYINT/BOOLEAN | Cancellation flag | Indicates if user cancelled order |

**Key Information:**
- Audit trail for order status changes
- Each status update creates a new tracking record
- Stores remarks/notes from admin about order
- Records whether cancellation was by user or system
- Used for displaying order history/tracking to customers

**Example Usage:**
```sql
INSERT INTO tblfoodtracking(OrderId,remark,status) VALUE('$oid','$remark','$ressta')
INSERT INTO tblfoodtracking(OrderId,remark,status,OrderCanclledByUser) VALUE('$oid','$remark','$status','$canclbyuser')

SELECT OrderCanclledByUser,remark,status,StatusDate FROM tblfoodtracking WHERE OrderId='$orderid'
```

---

### 7. **request** (Customer Requests/Inquiries)
**Purpose:** Stores customer requests or inquiries

**Fields:**
| Field Name | Data Type | Description | Notes |
|------------|-----------|-------------|-------|
| id | INT | Primary Key - Request ID | Auto-increment |
| name | VARCHAR | Requester name | Customer name |
| bname | VARCHAR | Business name | Name of business/restaurant |
| number | VARCHAR | Phone number | Contact number |
| email | VARCHAR | Email address | Contact email |
| address | VARCHAR | Address | Business or delivery address |

**Key Information:**
- Standalone table for customer requests/inquiries
- Can be used for new restaurant/business onboarding requests
- Stores contact information for follow-up

**Example Usage:**
```sql
INSERT INTO request(id,name,bname,number,email,address) 
VALUES(NULL,'$name','$bname','$num','$email','$address')
```

---

## Table Relationships

```
tbluser
├── (1:N) → tblorders (via UserId)
├── (1:N) → tblorderaddresses (via UserId)
└── (1:N) → tblfoodtracking (indirectly via OrderId)

tblfood
├── (N:1) → tblcategory (via CategoryName)
└── (1:N) → tblorders (via FoodId)

tblcategory
└── (1:N) → tblfood (via CategoryName)

tblorders
├── (N:1) → tbluser (via UserId)
├── (N:1) → tblfood (via FoodId)
└── (N:1) → tblorderaddresses (via OrderNumber/Ordernumber)

tblorderaddresses
├── (N:1) → tbluser (via UserId)
├── (1:N) → tblfoodtracking (via Ordernumber/OrderId)
└── (1:N) → tblorders (via Ordernumber/OrderNumber)

tblfoodtracking
└── (N:1) → tblorderaddresses (via OrderId/Ordernumber)

request
└── Standalone table
```

---

## Key Query Patterns

### User Operations
- **User Registration:** INSERT INTO tbluser(FirstName, LastName, MobileNumber, Email, Password)
- **User Login:** SELECT from tbluser WHERE (Email OR MobileNumber) AND Password
- **User Profile Update:** UPDATE tbluser SET FirstName, LastName WHERE ID

### Order Operations
- **Add to Cart:** INSERT INTO tblorders(UserId, FoodId, FoodQty)
- **Place Order:** UPDATE tblorders + INSERT INTO tblorderaddresses
- **Get Cart Items:** SELECT * FROM tblorders JOIN tblfood WHERE UserId AND IsOrderPlaced IS NULL
- **Get Order Details:** SELECT FROM tblorders JOIN tblfood WHERE OrderNumber

### Order Tracking
- **Update Order Status:** UPDATE tblorderaddresses + INSERT INTO tblfoodtracking
- **Track Order:** SELECT FROM tblfoodtracking WHERE OrderId
- **Get All Orders:** SELECT * FROM tblorderaddresses JOIN tbluser JOIN tblorders

### Category & Product Operations
- **Get Categories:** SELECT * FROM tblcategory WHERE Categorytype
- **Search Products:** SELECT * FROM tblfood WHERE ItemName LIKE OR CategoryName LIKE OR restname LIKE
- **Get Products by Category:** SELECT * FROM tblfood WHERE CategoryName

### Discount/Coupon Operations
- **Apply Coupon:** UPDATE tbluser SET Coupon WHERE ID
- **Clear Coupon:** UPDATE tbluser SET Coupon=NULL WHERE ID
- **Get Coupon:** SELECT Coupon FROM tbluser WHERE ID

---

## Data Types Used

| Type | Usage | Examples |
|------|-------|----------|
| INT | IDs, Quantities, Percentages | ID, FoodQty, Coupon |
| VARCHAR | Names, Emails, Strings | FirstName, Email, ItemName |
| TEXT | Descriptions, Remarks | ItemDes, remark |
| DECIMAL | Prices | ItemPrice |
| DATETIME | Timestamps | OrderTime, StatusDate |
| TINYINT/BOOLEAN | Flags/Status | IsOrderPlaced, OrderCanclledByUser |

---

## Notes

1. **Naming Inconsistency:** Some field names have inconsistent naming (e.g., "Ordernumber" vs "OrderNumber", "buldng" vs "building")

2. **Missing Constraints:** The actual database schema should include:
   - PRIMARY KEY constraints on all ID fields
   - FOREIGN KEY constraints between related tables
   - NOT NULL constraints on required fields
   - UNIQUE constraints on Email in tbluser
   - DEFAULT values and timestamps

3. **Image Storage:** Food item images are stored as MD5-hashed filenames with original extensions in `admin/itemimages/` directory

4. **Authentication:** System uses session-based authentication with `$_SESSION['fosuid']` for users and `$_SESSION['fosaid']` for admins

5. **Database Connection:** Located in `includes/dbconnection.php` connecting to MySQL database `fosdb`

---

## Last Updated
Based on code analysis completed as of November 30, 2025
