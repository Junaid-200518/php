-- Contact Us migration for an existing airline_reservation database.
-- Safe to run on an older database that does not yet have these fields.

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `customer_id` VARCHAR(20) NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `message` TEXT NOT NULL,
  `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reply` TEXT NULL,
  `replied_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_contact_customer_id` (`customer_id`),
  KEY `idx_contact_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- For an already-existing table, add missing fields only.
SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='contact_messages' AND COLUMN_NAME='customer_id')=0,
  'ALTER TABLE `contact_messages` ADD COLUMN `customer_id` VARCHAR(20) NULL AFTER `id`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='contact_messages' AND COLUMN_NAME='reply')=0,
  'ALTER TABLE `contact_messages` ADD COLUMN `reply` TEXT NULL AFTER `submitted_at`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF((SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='contact_messages' AND COLUMN_NAME='replied_at')=0,
  'ALTER TABLE `contact_messages` ADD COLUMN `replied_at` TIMESTAMP NULL DEFAULT NULL AFTER `reply`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
