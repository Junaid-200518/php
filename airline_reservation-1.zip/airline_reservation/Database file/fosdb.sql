-- FOS (Food Ordering System) Database Schema
-- Created: 2025-11-30
-- Database: fosdb

-- ===================================================================
-- Create Database
-- ===================================================================
CREATE DATABASE IF NOT EXISTS `fosdb`;
USE `fosdb`;

-- ===================================================================
-- Table: tbluser
-- Purpose: Store user account information
-- ===================================================================
CREATE TABLE IF NOT EXISTS `tbluser` (
  `ID` INT AUTO_INCREMENT PRIMARY KEY,
  `FirstName` VARCHAR(50) NOT NULL,
  `LastName` VARCHAR(50) NOT NULL,
  `MobileNumber` VARCHAR(15) UNIQUE NOT NULL,
  `Email` VARCHAR(100) UNIQUE NOT NULL,
  `Password` VARCHAR(255) NOT NULL,
  `Coupon` VARCHAR(50) DEFAULT NULL,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_email` (`Email`),
  INDEX `idx_mobile` (`MobileNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Table: tblcategory
-- Purpose: Store food categories
-- ===================================================================
CREATE TABLE IF NOT EXISTS `tblcategory` (
  `ID` INT AUTO_INCREMENT PRIMARY KEY,
  `CategoryName` VARCHAR(100) NOT NULL UNIQUE,
  `Categorytype` ENUM('Restaurant', 'Home made food') NOT NULL,
  `Description` TEXT DEFAULT NULL,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_category_name` (`CategoryName`),
  INDEX `idx_category_type` (`Categorytype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Table: tblfood
-- Purpose: Store food items/products
-- ===================================================================
CREATE TABLE IF NOT EXISTS `tblfood` (
  `ID` INT AUTO_INCREMENT PRIMARY KEY,
  `CategoryName` VARCHAR(100) NOT NULL,
  `ItemName` VARCHAR(150) NOT NULL,
  `ItemPrice` DECIMAL(10, 2) NOT NULL,
  `ItemDes` TEXT NOT NULL,
  `ItemQty` INT NOT NULL DEFAULT 0,
  `Image` VARCHAR(255) DEFAULT NULL,
  `restname` VARCHAR(100) DEFAULT NULL,
  `IsActive` TINYINT(1) DEFAULT 1,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`CategoryName`) REFERENCES `tblcategory`(`CategoryName`),
  INDEX `idx_category` (`CategoryName`),
  INDEX `idx_item_name` (`ItemName`),
  INDEX `idx_restaurant` (`restname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Table: tblorders
-- Purpose: Store user orders and shopping cart items
-- ===================================================================
CREATE TABLE IF NOT EXISTS `tblorders` (
  `ID` INT AUTO_INCREMENT PRIMARY KEY,
  `UserId` INT NOT NULL,
  `FoodId` INT NOT NULL,
  `FoodQty` INT NOT NULL DEFAULT 1,
  `OrderNumber` VARCHAR(50) DEFAULT NULL,
  `IsOrderPlaced` TINYINT(1) DEFAULT 0,
  `OrderPlacedAt` TIMESTAMP NULL DEFAULT NULL,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`UserId`) REFERENCES `tbluser`(`ID`) ON DELETE CASCADE,
  FOREIGN KEY (`FoodId`) REFERENCES `tblfood`(`ID`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`UserId`),
  INDEX `idx_food_id` (`FoodId`),
  INDEX `idx_order_number` (`OrderNumber`),
  INDEX `idx_is_order_placed` (`IsOrderPlaced`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Table: tblorderaddresses
-- Purpose: Store order delivery addresses and order metadata
-- ===================================================================
CREATE TABLE IF NOT EXISTS `tblorderaddresses` (
  `ID` INT AUTO_INCREMENT PRIMARY KEY,
  `UserId` INT NOT NULL,
  `Ordernumber` VARCHAR(50) NOT NULL UNIQUE,
  `Flatnobuldngno` VARCHAR(100) NOT NULL,
  `StreetName` VARCHAR(150) NOT NULL,
  `Area` VARCHAR(100) NOT NULL,
  `Landmark` VARCHAR(100) DEFAULT NULL,
  `City` VARCHAR(100) NOT NULL,
  `OrderTime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `OrderFinalStatus` VARCHAR(50) DEFAULT NULL,
  `TotalAmount` DECIMAL(10, 2) DEFAULT NULL,
  `PaymentStatus` VARCHAR(50) DEFAULT NULL,
  `DeliveryNotes` TEXT DEFAULT NULL,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  FOREIGN KEY (`UserId`) REFERENCES `tbluser`(`ID`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`UserId`),
  INDEX `idx_order_number` (`Ordernumber`),
  INDEX `idx_order_status` (`OrderFinalStatus`),
  INDEX `idx_order_date` (`OrderTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Table: tblfoodtracking
-- Purpose: Track order status and updates
-- ===================================================================
CREATE TABLE IF NOT EXISTS `tblfoodtracking` (
  `ID` INT AUTO_INCREMENT PRIMARY KEY,
  `OrderId` VARCHAR(50) NOT NULL,
  `remark` TEXT DEFAULT NULL,
  `status` VARCHAR(50) NOT NULL,
  `StatusDate` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `OrderCanclledByUser` TINYINT(1) DEFAULT 0,
  `CancellationReason` TEXT DEFAULT NULL,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_order_id` (`OrderId`),
  INDEX `idx_status` (`status`),
  INDEX `idx_status_date` (`StatusDate`),
  FOREIGN KEY (`OrderId`) REFERENCES `tblorderaddresses`(`Ordernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Table: request
-- Purpose: Store customer inquiries and feature requests
-- ===================================================================
CREATE TABLE IF NOT EXISTS `request` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `bname` VARCHAR(100) NOT NULL,
  `number` VARCHAR(15) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `address` TEXT NOT NULL,
  `CreatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_email` (`email`),
  INDEX `idx_phone` (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ===================================================================
-- Sample Data (Optional - Comment out if not needed)
-- ===================================================================

-- Sample Category
INSERT INTO `tblcategory` (`CategoryName`, `Categorytype`, `Description`) VALUES
('North Indian', 'Restaurant', 'Traditional North Indian dishes'),
('South Indian', 'Restaurant', 'Authentic South Indian cuisine'),
('Home Made Food', 'Home made food', 'Freshly prepared home-cooked meals'),
('Chinese', 'Restaurant', 'Chinese cuisine'),
('Continental', 'Restaurant', 'International continental dishes')
ON DUPLICATE KEY UPDATE `ID`=`ID`;

-- Sample User
INSERT INTO `tbluser` (`FirstName`, `LastName`, `MobileNumber`, `Email`, `Password`) VALUES
('John', 'Doe', '9999999999', 'john@example.com', MD5('password123'))
ON DUPLICATE KEY UPDATE `ID`=`ID`;

-- Sample Food Items
INSERT INTO `tblfood` (`CategoryName`, `ItemName`, `ItemPrice`, `ItemDes`, `ItemQty`, `restname`) VALUES
('North Indian', 'Aloo Paratha', 120.00, 'Delicious potato-filled paratha', 50, 'North Indian Delights'),
('North Indian', 'Chana Chaat', 100.00, 'Spicy chickpea snack', 30, 'North Indian Delights'),
('South Indian', 'Dosa', 80.00, 'Crispy rice pancake', 40, 'South Indian Express'),
('Home Made Food', 'Special Veg Thali', 150.00, 'Complete meal with vegetables', 25, 'Home Chef'),
('North Indian', 'Egg Fry', 50.00, 'Fried eggs with spices', 60, 'North Indian Delights'),
('North Indian', 'Chicken Lababdar', 250.00, 'Creamy chicken curry', 35, 'North Indian Delights'),
('Home Made Food', 'Mix Veg Paratha', 100.00, 'Paratha with mixed vegetables', 45, 'Home Chef')
ON DUPLICATE KEY UPDATE `ID`=`ID`;

-- ===================================================================
-- Views (Optional - for easier reporting)
-- ===================================================================

-- View: Active Orders
CREATE OR REPLACE VIEW `active_orders` AS
SELECT 
  oa.`ID`,
  oa.`Ordernumber`,
  u.`FirstName`,
  u.`LastName`,
  u.`Email`,
  u.`MobileNumber`,
  oa.`OrderTime`,
  oa.`OrderFinalStatus`,
  oa.`TotalAmount`,
  CONCAT(oa.`Flatnobuldngno`, ', ', oa.`StreetName`, ', ', oa.`Area`, ', ', oa.`City`) AS `FullAddress`
FROM `tblorderaddresses` oa
JOIN `tbluser` u ON oa.`UserId` = u.`ID`
WHERE oa.`OrderFinalStatus` IS NULL OR oa.`OrderFinalStatus` NOT IN ('Order Delivered', 'Order Cancelled')
ORDER BY oa.`OrderTime` DESC;

-- View: Order Summary
CREATE OR REPLACE VIEW `order_summary` AS
SELECT 
  oa.`Ordernumber`,
  u.`FirstName`,
  u.`LastName`,
  COUNT(o.`ID`) AS `ItemCount`,
  SUM(o.`FoodQty`) AS `TotalQty`,
  oa.`OrderFinalStatus`,
  oa.`OrderTime`,
  oa.`TotalAmount`
FROM `tblorderaddresses` oa
JOIN `tbluser` u ON oa.`UserId` = u.`ID`
LEFT JOIN `tblorders` o ON o.`OrderNumber` = oa.`Ordernumber`
GROUP BY oa.`Ordernumber`;

-- ===================================================================
-- Indexes for Better Performance
-- ===================================================================
CREATE INDEX `idx_order_user` ON `tblorders`(`UserId`, `IsOrderPlaced`);
CREATE INDEX `idx_address_status_date` ON `tblorderaddresses`(`OrderFinalStatus`, `OrderTime`);
CREATE INDEX `idx_tracking_order_status` ON `tblfoodtracking`(`OrderId`, `status`);

-- ===================================================================
-- End of Schema
-- ===================================================================
