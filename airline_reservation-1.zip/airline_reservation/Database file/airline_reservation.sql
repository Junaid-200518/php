-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2017 at 04:09 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airline_reservation`
--

--
-- Procedures
--
DROP PROCEDURE IF EXISTS `GetFlightStatistics`;
DELIMITER $$
CREATE PROCEDURE `GetFlightStatistics` (IN `j_date` DATE)
BEGIN
    SELECT
        k.flight_no,
        k.departure_date,
        IFNULL(k.no_of_passengers, 0) AS no_of_passengers,
        k.total_capacity
    FROM (
        SELECT
            f.flight_no,
            f.departure_date,
            SUM(t.no_of_passengers) AS no_of_passengers,
            j.total_capacity
        FROM flight_details AS f
        LEFT JOIN ticket_details AS t
            ON t.booking_status = 'CONFIRMED'
            AND t.flight_no = f.flight_no
            AND f.departure_date = t.journey_date
        INNER JOIN jet_details AS j
            ON j.jet_id = f.jet_id
        GROUP BY f.flight_no, f.departure_date, j.total_capacity
    ) AS k
    WHERE k.departure_date = j_date;
END$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(20) NOT NULL,
  `pwd` varchar(30) DEFAULT NULL,
  `staff_id` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `pwd`, `staff_id`, `name`, `email`) VALUES
('roshan', 'passpass', '101', 'Harry Roshan', 'harryroshan1997@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` varchar(20) NOT NULL,
  `pwd` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `address` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `pwd`, `name`, `email`, `phone_no`, `address`) VALUES
('aadith', 'aadith007', 'aadith_name', 'aadith_email', '12345', 'aadith_address'),
('Apple', 'abhishek', 'Abhijeeth', 'gmail@gmail.com', '+9185564764', 'hgsjhgdjfdjdgf'),
('blah', 'blah blah', 'blah', 'blah@gmail.com', '993498570', 'blah'),
('charles', 'charles_pass', 'Charles', 'charles@gmail.com', '9090909090', 'Bangalore'),
('chirag008', 'chirag', 'Chirag G', 'chirag@gmail.com', '8080808080', 'Kuldlu Gate'),
('harryroshan', 'passpasshello', 'Harry Roshan', 'harryroshan1997@gmai', '9845713736', '#381, 1st E Main,');

-- --------------------------------------------------------

--
-- Table structure for table `flight_details`
--

CREATE TABLE `flight_details` (
  `flight_no` varchar(10) NOT NULL,
  `from_city` varchar(20) DEFAULT NULL,
  `to_city` varchar(20) DEFAULT NULL,
  `departure_date` date NOT NULL,
  `arrival_date` date DEFAULT NULL,
  `departure_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `seats_economy` int(5) DEFAULT NULL,
  `seats_business` int(5) DEFAULT NULL,
  `price_economy` int(10) DEFAULT NULL,
  `price_business` int(10) DEFAULT NULL,
  `jet_id` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight_details`
--

INSERT INTO `flight_details` (`flight_no`, `from_city`, `to_city`, `departure_date`, `arrival_date`, `departure_time`, `arrival_time`, `seats_economy`, `seats_business`, `price_economy`, `price_business`, `jet_id`) VALUES
('AA201', 'delhi', 'mumbai', '2025-05-10', '2025-05-10', '09:30:00', '11:45:00', 180, 90, 4000, 5500, '10001'),
('AA202', 'kolkata', 'chennai', '2025-06-12', '2025-06-12', '14:15:00', '16:30:00', 160, 60, 3500, 5000, '10002'),
('AA203', 'mumbai', 'hyderabad', '2025-07-01', '2025-07-01', '07:00:00', '08:15:00', 170, 85, 3200, 4500, '10003'),
('AA204', 'ahmedabad', 'bangalore', '2025-08-18', '2025-08-18', '19:45:00', '22:15:00', 200, 110, 4100, 6000, '10004'),
('AA205', 'pune', 'goa', '2025-09-05', '2025-09-05', '06:30:00', '07:20:00', 100, 40, 1500, 2200, '10007'),
('AA206', 'jaipur', 'delhi', '2025-10-11', '2025-10-11', '08:00:00', '08:50:00', 120, 55, 1800, 2500, '10001'),
('AA207', 'lucknow', 'patna', '2025-11-23', '2025-11-23', '17:10:00', '18:05:00', 110, 30, 1600, 2000, '10002'),
('AA208', 'cochin', 'trivandrum', '2025-04-25', '2025-04-25', '12:00:00', '13:00:00', 90, 20, 1000, 1300, '10003'),
('AA209', 'bhubaneswar', 'vizag', '2025-03-14', '2025-03-14', '15:45:00', '16:45:00', 140, 65, 2000, 2700, '10004'),
('AA210', 'ranchi', 'kolkata', '2025-02-28', '2025-02-28', '18:30:00', '19:45:00', 130, 50, 1700, 2400, '10007'),
('SK301', 'patna', 'mumbai', '2026-08-17', '2026-08-17', '10:15:00', '13:30:00', 100, 80, 3000, 5500, '10004'),
('SK302', 'bangalore', 'surat', '2026-08-15', '2026-08-15', '06:00:00', '07:45:00', 120, 20, 1500, 3300, '10002'),
('SK303', 'indore', 'pune', '2026-08-18', '2026-08-18', '11:45:00', '12:45:00', 180, 80, 4000, 6500, '10001'),
('SK304', 'trivandrum', 'nagpur', '2026-08-13', '2026-08-13', '07:30:00', '10:15:00', 180, 20, 3500, 6000, '10007'),
('SK305', 'nagpur', 'lucknow', '2026-08-14', '2026-08-14', '14:30:00', '15:00:00', 120, 40, 1500, 3300, '10002'),
('SK306', 'patna', 'kolkata', '2026-08-18', '2026-08-18', '10:15:00', '13:00:00', 120, 60, 4000, 6500, '10002'),
('SK307', 'patna', 'cochin', '2026-08-14', '2026-08-14', '09:00:00', '10:45:00', 80, 30, 3500, 5500, '10002'),
('SK308', 'jaipur', 'ahmedabad', '2026-08-15', '2026-08-15', '09:00:00', '12:00:00', 150, 20, 4500, 6000, '10002'),
('SK309', 'chennai', 'lucknow', '2026-08-19', '2026-08-19', '16:00:00', '18:30:00', 100, 30, 1500, 3000, '10004'),
('SK310', 'bangalore', 'cochin', '2026-08-15', '2026-08-15', '11:45:00', '12:30:00', 120, 80, 4000, 6500, '10003'),
('SK311', 'lucknow', 'cochin', '2026-08-13', '2026-08-13', '07:30:00', '09:15:00', 180, 40, 1500, 2700, '10007'),
('SK312', 'kolkata', 'ranchi', '2026-08-16', '2026-08-16', '13:00:00', '16:30:00', 150, 60, 1800, 3800, '10007'),
('SK313', 'bangalore', 'kolkata', '2026-08-14', '2026-08-14', '11:45:00', '12:45:00', 80, 60, 2500, 4300, '10004'),
('SK314', 'surat', 'goa', '2026-08-13', '2026-08-13', '20:30:00', '22:30:00', 200, 20, 3000, 5500, '10003'),
('SK315', 'trivandrum', 'delhi', '2026-08-18', '2026-08-18', '14:30:00', '16:45:00', 200, 40, 2200, 3700, '10004'),
('SK316', 'nagpur', 'indore', '2026-08-18', '2026-08-18', '14:30:00', '17:15:00', 180, 60, 3000, 5000, '10007'),
('SK317', 'ahmedabad', 'pune', '2026-08-19', '2026-08-19', '06:00:00', '08:30:00', 100, 50, 3500, 5500, '10004'),
('SK318', 'lucknow', 'goa', '2026-08-16', '2026-08-16', '20:30:00', '21:45:00', 200, 30, 1800, 3600, '10007'),
('SK319', 'patna', 'delhi', '2026-08-18', '2026-08-18', '20:30:00', '23:30:00', 80, 30, 3000, 4500, '10002'),
('SK320', 'indore', 'vizag', '2026-08-14', '2026-08-14', '06:00:00', '07:15:00', 150, 60, 1800, 3800, '10004'),
('SK321', 'cochin', 'vizag', '2026-08-18', '2026-08-18', '19:00:00', '20:45:00', 150, 50, 2500, 4000, '10001'),
('SK322', 'bhubaneswar', 'kolkata', '2026-08-19', '2026-08-19', '07:30:00', '09:15:00', 100, 80, 4500, 5700, '10007'),
('SK323', 'bhubaneswar', 'vizag', '2026-08-14', '2026-08-14', '07:30:00', '09:15:00', 150, 80, 3500, 5500, '10007'),
('SK324', 'vizag', 'bhubaneswar', '2026-08-19', '2026-08-19', '22:00:00', '01:45:00', 180, 50, 2200, 4200, '10004'),
('SK325', 'bhubaneswar', 'chennai', '2026-08-15', '2026-08-15', '10:15:00', '13:30:00', 180, 50, 2500, 4300, '10004'),
('SK326', 'mumbai', 'ranchi', '2026-08-13', '2026-08-13', '22:00:00', '00:15:00', 120, 40, 3500, 6000, '10001'),
('SK327', 'kolkata', 'indore', '2026-08-14', '2026-08-14', '09:00:00', '10:45:00', 200, 30, 2500, 3700, '10004'),
('SK328', 'indore', 'lucknow', '2026-08-16', '2026-08-16', '13:00:00', '16:45:00', 150, 20, 2500, 4500, '10004'),
('SK329', 'ahmedabad', 'hyderabad', '2026-08-19', '2026-08-19', '19:00:00', '22:00:00', 180, 50, 4500, 5700, '10003'),
('SK330', 'ahmedabad', 'lucknow', '2026-08-15', '2026-08-15', '14:30:00', '16:15:00', 150, 30, 3000, 5000, '10004'),
('SK331', 'hyderabad', 'trivandrum', '2026-08-13', '2026-08-13', '14:30:00', '16:45:00', 200, 30, 4500, 6000, '10007'),
('SK332', 'ranchi', 'chennai', '2026-08-17', '2026-08-17', '06:00:00', '08:00:00', 80, 80, 4000, 5500, '10004'),
('SK333', 'hyderabad', 'surat', '2026-08-14', '2026-08-14', '06:00:00', '08:45:00', 120, 30, 4500, 6300, '10003'),
('SK334', 'hyderabad', 'indore', '2026-08-19', '2026-08-19', '14:30:00', '16:45:00', 120, 20, 4500, 5700, '10007'),
('SK335', 'patna', 'chennai', '2026-08-13', '2026-08-13', '13:00:00', '14:00:00', 200, 20, 1500, 3000, '10002'),
('SK336', 'kolkata', 'ahmedabad', '2026-08-19', '2026-08-19', '06:00:00', '09:15:00', 100, 30, 4500, 5700, '10007'),
('SK337', 'mumbai', 'patna', '2026-08-14', '2026-08-14', '16:00:00', '19:30:00', 120, 30, 1800, 3300, '10003'),
('SK338', 'ahmedabad', 'nagpur', '2026-08-13', '2026-08-13', '19:00:00', '20:30:00', 180, 80, 4000, 6000, '10002'),
('SK339', 'chennai', 'ranchi', '2026-08-13', '2026-08-13', '19:00:00', '22:15:00', 80, 80, 3000, 5500, '10001'),
('SK340', 'hyderabad', 'lucknow', '2026-08-19', '2026-08-19', '19:00:00', '20:30:00', 180, 50, 3500, 4700, '10007'),
('SK341', 'bhubaneswar', 'ranchi', '2026-08-18', '2026-08-18', '13:00:00', '14:45:00', 150, 20, 4000, 5800, '10004'),
('SK342', 'pune', 'surat', '2026-08-18', '2026-08-18', '09:00:00', '11:15:00', 200, 60, 3000, 5500, '10007'),
('SK343', 'bhubaneswar', 'mumbai', '2026-08-19', '2026-08-19', '16:00:00', '18:45:00', 200, 60, 3000, 4800, '10002'),
('SK344', 'surat', 'delhi', '2026-08-19', '2026-08-19', '07:30:00', '09:45:00', 100, 50, 4000, 5800, '10001'),
('SK345', 'bhubaneswar', 'lucknow', '2026-08-16', '2026-08-16', '13:00:00', '14:45:00', 100, 40, 3000, 4800, '10003'),
('SK346', 'goa', 'surat', '2026-08-17', '2026-08-17', '22:00:00', '00:00:00', 180, 30, 1800, 3300, '10004'),
('SK347', 'vizag', 'pune', '2026-08-16', '2026-08-16', '17:30:00', '18:45:00', 200, 80, 4500, 6500, '10001'),
('SK348', 'hyderabad', 'ranchi', '2026-08-13', '2026-08-13', '11:45:00', '12:45:00', 200, 30, 3000, 5500, '10003'),
('SK349', 'pune', 'nagpur', '2026-08-16', '2026-08-16', '17:30:00', '20:30:00', 150, 80, 3500, 5300, '10004'),
('SK350', 'jaipur', 'indore', '2026-08-15', '2026-08-15', '11:45:00', '13:15:00', 80, 80, 2500, 4300, '10001'),
('SK351', 'lucknow', 'delhi', '2026-08-18', '2026-08-18', '17:30:00', '20:15:00', 100, 30, 4500, 6300, '10007'),
('SK352', 'mumbai', 'goa', '2026-08-19', '2026-08-19', '17:30:00', '20:30:00', 80, 30, 3000, 4500, '10003'),
('SK353', 'nagpur', 'ahmedabad', '2026-08-14', '2026-08-14', '11:45:00', '12:15:00', 120, 20, 1500, 4000, '10003'),
('SK354', 'patna', 'vizag', '2026-08-18', '2026-08-18', '09:00:00', '12:45:00', 80, 20, 3000, 5000, '10004'),
('SK355', 'delhi', 'chennai', '2026-08-16', '2026-08-16', '13:00:00', '14:00:00', 120, 50, 1800, 3000, '10004'),
('SK356', 'kolkata', 'delhi', '2026-08-16', '2026-08-16', '07:30:00', '10:00:00', 100, 30, 3000, 4200, '10002'),
('SK357', 'indore', 'cochin', '2026-08-13', '2026-08-13', '17:30:00', '19:15:00', 180, 50, 4500, 6500, '10003'),
('SK358', 'jaipur', 'hyderabad', '2026-08-19', '2026-08-19', '19:00:00', '21:30:00', 180, 60, 1500, 4000, '10001'),
('SK359', 'hyderabad', 'bhubaneswar', '2026-08-19', '2026-08-19', '10:15:00', '13:15:00', 120, 80, 1800, 3300, '10002'),
('SK360', 'trivandrum', 'pune', '2026-08-14', '2026-08-14', '17:30:00', '18:15:00', 80, 50, 4500, 7000, '10004');


-- --------------------------------------------------------

--
-- Table structure for table `frequent_flier_details`
--

CREATE TABLE `frequent_flier_details` (
  `frequent_flier_no` varchar(20) NOT NULL,
  `customer_id` varchar(20) DEFAULT NULL,
  `mileage` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `frequent_flier_details`
--

INSERT INTO `frequent_flier_details` (`frequent_flier_no`, `customer_id`, `mileage`) VALUES
('10001000', 'aadith', 375),
('20002000', 'harryroshan', 150);

-- --------------------------------------------------------

--
-- Table structure for table `jet_details`
--

CREATE TABLE `jet_details` (
  `jet_id` varchar(10) NOT NULL,
  `jet_type` varchar(20) DEFAULT NULL,
  `total_capacity` int(5) DEFAULT NULL,
  `active` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jet_details`
--

INSERT INTO `jet_details` (`jet_id`, `jet_type`, `total_capacity`, `active`) VALUES
('10001', 'Dreamliner', 300, 'Yes'),
('10002', 'Airbus A380', 275, 'Yes'),
('10003', 'ATR', 50, 'Yes'),
('10004', 'Boeing 737', 225, 'Yes'),
('10007', 'Test_Model', 250, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `passenger_id` int(10) NOT NULL,
  `pnr` varchar(15) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `gender` varchar(8) DEFAULT NULL,
  `meal_choice` varchar(5) DEFAULT NULL,
  `frequent_flier_no` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`passenger_id`, `pnr`, `name`, `age`, `gender`, `meal_choice`, `frequent_flier_no`) VALUES
(1, '1669050', 'Harry Roshan', 20, 'male', 'yes', '20002000'),
(1, '2369143', 'blah', 20, 'male', 'yes', NULL),
(1, '3027167', 'aadith_name', 10, 'male', 'yes', NULL),
(1, '3773951', 'harry', 51, 'male', 'yes', NULL),
(1, '4797983', 'pass1', 34, 'male', 'yes', NULL),
(1, '5421865', 'pass1', 10, 'male', 'yes', NULL),
(1, '6980157', 'roshan', 20, 'male', 'yes', NULL),
(1, '8503285', 'aadith_name', 10, 'male', 'yes', '10001000'),
(2, '1669050', 'berti harry', 45, 'female', 'yes', NULL),
(2, '2369143', 'blah', 51, 'male', 'yes', NULL),
(2, '3027167', 'roshan', 20, 'male', 'yes', NULL),
(2, '3773951', 'berti', 42, 'female', 'yes', NULL),
(2, '4797983', 'Harry Roshan', 20, 'male', 'yes', '20002000'),
(2, '5421865', 'pass2', 20, 'female', 'yes', NULL),
(2, '6980157', 'aadith', 9, 'male', 'yes', NULL),
(2, '8503285', 'roshan_name', 20, 'male', 'yes', NULL),
(3, '1669050', 'aadith_name', 10, 'male', 'yes', NULL),
(3, '2369143', 'blah', 10, 'male', 'yes', NULL),
(3, '3773951', 'aadith', 11, 'male', 'yes', '10001000'),
(3, '4797983', 'aadith_name', 10, 'male', 'yes', '10001000'),
(3, '5421865', 'pass3', 30, 'male', 'yes', NULL),
(4, '2369143', 'blah', 42, 'female', 'yes', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `payment_id` varchar(20) NOT NULL,
  `pnr` varchar(15) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_amount` int(6) DEFAULT NULL,
  `payment_mode` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`payment_id`, `pnr`, `payment_date`, `payment_amount`, `payment_mode`) VALUES
('120000248', '4797983', '2017-11-25', 4200, 'credit card'),
('142539461', '3773951', '2017-11-25', 4050, 'credit card'),
('165125569', '8503285', '2017-11-25', 7500, 'net banking'),
('467972527', '2369143', '2017-11-26', 33400, 'debit card'),
('557778944', '6980157', '2017-11-26', 11700, 'credit card'),
('620041544', '1669050', '2017-11-25', 4800, 'debit card'),
('665360715', '5421865', '2017-11-28', 15750, 'net banking'),
('862686553', '3027167', '2017-11-25', 10700, 'debit card');

--
-- Triggers `payment_details`
--
DELIMITER $$
CREATE TRIGGER `update_ticket_after_payment` AFTER INSERT ON `payment_details` FOR EACH ROW UPDATE ticket_details
     SET booking_status='CONFIRMED', payment_id= NEW.payment_id
   WHERE pnr = NEW.pnr
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_details`
--

CREATE TABLE `ticket_details` (
  `pnr` varchar(15) NOT NULL,
  `date_of_reservation` date DEFAULT NULL,
  `flight_no` varchar(10) DEFAULT NULL,
  `journey_date` date DEFAULT NULL,
  `class` varchar(10) DEFAULT NULL,
  `booking_status` varchar(20) DEFAULT NULL,
  `no_of_passengers` int(5) DEFAULT NULL,
  `lounge_access` varchar(5) DEFAULT NULL,
  `priority_checkin` varchar(5) DEFAULT NULL,
  `insurance` varchar(5) DEFAULT NULL,
  `payment_id` varchar(20) DEFAULT NULL,
  `customer_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_details`
--

INSERT INTO `ticket_details` (`pnr`, `date_of_reservation`, `flight_no`, `journey_date`, `class`, `booking_status`, `no_of_passengers`, `lounge_access`, `priority_checkin`, `insurance`, `payment_id`, `customer_id`) VALUES
('1669050', '2017-11-25', 'AA204', '2025-08-18', 'business', 'CONFIRMED', 3, 'yes', 'yes', 'yes', '620041544', 'harryroshan'),
('2369143', '2017-11-26', 'AA201', '2025-05-10', 'business', 'CONFIRMED', 4, 'yes', 'yes', 'yes', '467972527', 'blah'),
('3027167', '2017-11-25', 'AA201', '2025-05-10', 'economy', 'CONFIRMED', 2, 'no', 'no', 'yes', '862686553', 'aadith'),
('3773951', '2017-11-25', 'AA204', '2025-08-18', 'economy', 'CONFIRMED', 3, 'yes', 'yes', 'yes', '142539461', 'aadith'),
('4797983', '2017-11-25', 'AA204', '2025-08-18', 'business', 'CONFIRMED', 3, 'yes', 'no', 'yes', '120000248', 'harryroshan'),
('5421865', '2017-11-28', 'AA201', '2025-05-10', 'economy', 'CONFIRMED', 3, 'no', 'no', 'no', '665360715', 'harryroshan'),
('6980157', '2017-11-26', 'AA201', '2025-05-10', 'economy', 'CANCELED', 2, 'yes', 'yes', 'yes', '557778944', 'aadith'),
('8503285', '2017-11-25', 'AA202', '2025-06-12', 'business', 'CONFIRMED', 2, 'yes', 'yes', 'no', '165125569', 'aadith');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `flight_details`
--
ALTER TABLE `flight_details`
  ADD PRIMARY KEY (`flight_no`,`departure_date`),
  ADD KEY `jet_id` (`jet_id`);

--
-- Indexes for table `frequent_flier_details`
--
ALTER TABLE `frequent_flier_details`
  ADD PRIMARY KEY (`frequent_flier_no`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `jet_details`
--
ALTER TABLE `jet_details`
  ADD PRIMARY KEY (`jet_id`);

--
-- Indexes for table `passengers`
--
ALTER TABLE `passengers`
  ADD PRIMARY KEY (`passenger_id`,`pnr`),
  ADD KEY `pnr` (`pnr`),
  ADD KEY `frequent_flier_no` (`frequent_flier_no`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `pnr` (`pnr`);

--
-- Indexes for table `ticket_details`
--
ALTER TABLE `ticket_details`
  ADD PRIMARY KEY (`pnr`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `journey_date` (`journey_date`),
  ADD KEY `flight_no` (`flight_no`),
  ADD KEY `flight_no_2` (`flight_no`,`journey_date`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `flight_details`
--
ALTER TABLE `flight_details`
  ADD CONSTRAINT `flight_details_ibfk_1` FOREIGN KEY (`jet_id`) REFERENCES `jet_details` (`jet_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `frequent_flier_details`
--
ALTER TABLE `frequent_flier_details`
  ADD CONSTRAINT `frequent_flier_details_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `passengers`
--
ALTER TABLE `passengers`
  ADD CONSTRAINT `passengers_ibfk_1` FOREIGN KEY (`pnr`) REFERENCES `ticket_details` (`pnr`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `passengers_ibfk_2` FOREIGN KEY (`frequent_flier_no`) REFERENCES `frequent_flier_details` (`frequent_flier_no`) ON UPDATE CASCADE;

--
-- Constraints for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD CONSTRAINT `payment_details_ibfk_1` FOREIGN KEY (`pnr`) REFERENCES `ticket_details` (`pnr`) ON UPDATE CASCADE;

--
-- Constraints for table `ticket_details`
--
ALTER TABLE `ticket_details`
  ADD CONSTRAINT `ticket_details_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ticket_details_ibfk_3` FOREIGN KEY (`flight_no`,`journey_date`) REFERENCES `flight_details` (`flight_no`, `departure_date`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

-- --------------------------------------------------------
--
-- Table structure for table `booking_details`
--

CREATE TABLE `booking_details` (
  `pnr` VARCHAR(20) NOT NULL,
  `flight_no` VARCHAR(20) NOT NULL,
  `journey_date` DATE NOT NULL,
  `p_name` VARCHAR(50) NOT NULL,
  `gender` VARCHAR(10),
  `age` INT(3),
  `meal_choice` VARCHAR(5), 
  `email` VARCHAR(50),
  `phone` VARCHAR(20),
  `seat_no` VARCHAR(10)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
--
-- Table structure for table `contact_messages`
-- Stores queries submitted by users via the Contact Us form
-- so they can be viewed by the Admin (admin_view_messages.php)
--

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT(10) NOT NULL AUTO_INCREMENT,
  `customer_id` VARCHAR(20) NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `message` TEXT NOT NULL,
  `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reply` TEXT NULL,
  `replied_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_contact_customer_id` (`customer_id`),
  KEY `idx_contact_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
