<?php
// Contact Us database setup. This only manages the contact_messages table.
// It is safe to run on every Contact Us page/action.
function ensure_contact_messages_table($dbc) {
    $create = "CREATE TABLE IF NOT EXISTS `contact_messages` (
        `id` INT(10) NOT NULL AUTO_INCREMENT,
        `customer_id` VARCHAR(20) NULL,
        `name` VARCHAR(100) NOT NULL,
        `email` VARCHAR(100) NOT NULL,
        `message` TEXT NOT NULL,
        `submitted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `reply` TEXT NULL,
        `replied_at` TIMESTAMP NULL DEFAULT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_contact_customer_id` (`customer_id`),
        KEY `idx_contact_email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1";
    if (!mysqli_query($dbc, $create)) {
        return false;
    }

    $columns = array();
    $res = mysqli_query($dbc, "SHOW COLUMNS FROM `contact_messages`");
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $columns[$row['Field']] = true;
        }
        mysqli_free_result($res);
    }

    if (!isset($columns['customer_id'])) {
        @mysqli_query($dbc, "ALTER TABLE `contact_messages` ADD COLUMN `customer_id` VARCHAR(20) NULL AFTER `id`");
        @mysqli_query($dbc, "ALTER TABLE `contact_messages` ADD KEY `idx_contact_customer_id` (`customer_id`)");
    }
    if (!isset($columns['reply'])) {
        @mysqli_query($dbc, "ALTER TABLE `contact_messages` ADD COLUMN `reply` TEXT NULL AFTER `submitted_at`");
    }
    if (!isset($columns['replied_at'])) {
        @mysqli_query($dbc, "ALTER TABLE `contact_messages` ADD COLUMN `replied_at` TIMESTAMP NULL DEFAULT NULL AFTER `reply`");
    }
    return true;
}
?>
