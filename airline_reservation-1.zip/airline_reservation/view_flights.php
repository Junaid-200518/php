<?php
require_once('Database Connection file/mysqli_connect.php');

$current_date = date('Y-m-d');
$query = "SELECT flight_no, from_city, to_city, departure_date, arrival_date, departure_time, arrival_time, seats_economy, seats_business, price_economy, price_business FROM Flight_Details WHERE departure_date >= '" . $current_date . "' ORDER BY departure_date, departure_time";
$result = mysqli_query($dbc, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Available Flights - SKY HIGH Airlines</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #e6f0ff; /* light blue background */
            color: #030337;
            margin: 0;
            padding: 0;
        }
        h2 {
            text-align: center;
            margin-top: 40px;
            color: #030337;
            font-size: 28px;
        }
        table {
            width: 95%;
            margin: 30px auto;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            text-align: center;
        }
        th {
            background-color: #003366;
            color: #fff;
            font-weight: bold;
        }
        tr {
            background-color: #ffffff;
            transition: background 0.3s;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #cce0ff;
        }
        td {
            border-bottom: 1px solid #ddd;
        }
        tr:last-child td {
            border-bottom: none;
        }
        .button-container {
            text-align: center;
            margin-bottom: 40px;
        }
        .button-container button {
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px 30px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        .button-container button:hover {
            background-color: #6699ff;
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <h2>Available Flight Schedules</h2>
    <table>
        <tr>
            <th>Flight No</th>
            <th>From</th>
            <th>To</th>
            <th>Departure Date</th>
            <th>Arrival Date</th>
            <th>Departure Time</th>
            <th>Arrival Time</th>
            <th>Seats (Economy)</th>
            <th>Seats (Business)</th>
            <th>Price (Economy)</th>
            <th>Price (Business)</th>
        </tr>
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['flight_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['from_city']); ?></td>
                    <td><?php echo htmlspecialchars($row['to_city']); ?></td>
                    <td><?php echo htmlspecialchars($row['departure_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['arrival_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['departure_time']); ?></td>
                    <td><?php echo htmlspecialchars($row['arrival_time']); ?></td>
                    <td><?php echo htmlspecialchars($row['seats_economy']); ?></td>
                    <td><?php echo htmlspecialchars($row['seats_business']); ?></td>
                    <td><?php echo htmlspecialchars($row['price_economy']); ?></td>
                    <td><?php echo htmlspecialchars($row['price_business']); ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="11">No flights found.</td></tr>
        <?php endif; ?>
    </table>

    <div class="button-container">
        <a href="admin_homepage.php"><button>Back to Admin Panel</button></a>
    </div>
</body>
</html>
<?php
if ($result) mysqli_free_result($result);
mysqli_close($dbc);
?>
