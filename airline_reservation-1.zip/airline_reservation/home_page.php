<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to SKY HIGH Airlines</title>
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <style>
    /* Animated background */
    body {
      margin: 0;
      font-family: 'Segoe UI', Arial, Helvetica, sans-serif;
      background: linear-gradient(120deg,#e0eafc 0%,#cfdef3 100%);
      background-size: 400% 400%;
      animation: gradientBG 15s ease infinite;
      color: #222;
    }
    @keyframes gradientBG {
      0% {background-position: 0% 50%;}
      50% {background-position: 100% 50%;}
      100% {background-position: 0% 50%;}
    }
    

    /* Logo */
    .logo {
      display: block;
      margin: 20px auto;
      width: 120px;
      border-radius: 12px;
      box-shadow: 0 6px 16px rgba(0,0,0,0.15);
      transition: transform 0.3s ease;
      object-fit: cover;
    }
    .logo:hover {transform: scale(1.05);}

    /* Title */
    #title {
      text-align: center;
      font-size: 2.8rem;
      font-weight: 700;
      color: #003366;
      position: relative;
      text-shadow: 1px 1px 4px rgba(0,0,0,0.1);
    }
    #title::after {
      content: "";
      position: absolute;
      width: 80px;
      height: 4px;
      background: linear-gradient(90deg,#ff6600,#ffcc00);
      bottom: -8px;
      left: 50%;
      transform: translateX(-50%);
      border-radius: 4px;
    }

    /* Navbar */
    ul.navbar {
      list-style: none;
      margin: 0;
      padding: 10px 0;
      background: #003366;
      text-align: center;
      border-radius: 0 0 12px 12px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.1);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    ul.navbar li {
      display: inline-block;
      margin: 0 8px;
    }
    ul.navbar li a {
      color: #fff;
      text-decoration: none;
      padding: 10px 16px;
      border-radius: 6px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    ul.navbar li a:hover {
      background: #ff6600;
      color: #fff;
      box-shadow: 0 4px 12px rgba(255,102,0,0.3);
      transform: translateY(-2px);
    }

    /* Hero container */
    .container {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
      padding: 32px 28px;
      margin: 40px auto;
      max-width: 1000px;
      text-align: center;
      animation: fadeInUp 1s ease forwards;
    }
    @keyframes fadeInUp {
      0% {opacity: 0; transform: translateY(30px);}
      100% {opacity: 1; transform: translateY(0);}
    }
    .welcome_text {
      font-size: 2.4rem;
      font-weight: bold;
      background: linear-gradient(90deg,#003366,#ff6600);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin: 20px 0;
      letter-spacing: 1px;
    }
    .container img {
      width: 100%;
      height: auto;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    /* Contact & Customer Care flex */
    .contact-care-flex {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin: 40px auto;
      max-width: 1000px;
      flex-wrap: wrap;
    }
    .contact-section {
      flex: 1 1 350px;
      background: #fff;
      padding: 30px 25px;
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
      min-width: 320px;
      text-align: center;
      animation: fadeInUp 1.2s ease forwards;
    }
    .contact-section h2 {
      color: #003366;
      margin-bottom: 10px;
    }
    .contact-section p {
      color: #666;
      font-size: 16px;
      margin-bottom: 20px;
    }

    /* Form */
    .contact-form input,
    .contact-form textarea {
      width: 100%;
      margin-bottom: 14px;
      padding: 14px;
      border: 1.5px solid #003366;
      border-radius: 8px;
      font-size: 1rem;
      background: #f7faff;
      transition: border 0.3s ease, box-shadow 0.3s ease;
    }
    .contact-form input:focus,
    .contact-form textarea:focus {
      border-color: #ff6600;
      outline: none;
      box-shadow: 0 0 8px rgba(255,102,0,0.2);
    }
    .contact-form button {
      background: linear-gradient(90deg,#003366,#00509e);
      color: #fff;
      border: none;
      border-radius: 30px;
      padding: 12px 36px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      transition: all 0.3s ease;
    }
    .contact-form button:hover {
      background: linear-gradient(90deg,#ff6600,#ff9900);
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(255,102,0,0.3);
    }

    footer {
      text-align:center;
      font-size:15px;
      color:#666;
      margin: 40px 0 10px 0;
    }
    footer a {
      color:#666;
      text-decoration:underline;
    }

    @media (max-width: 900px) {
      .welcome_text {font-size:1.6rem;}
    }
    .slider {
    position: relative;
    width: 100%;
    height: 500px;
    overflow: hidden;
    border-radius: 12px;
}

.slider .slide {
    position: absolute;
    top: 0;
    left: 0;
    width: 100% !important;
    height: 100% !important;
    object-fit: cover;
    opacity: 0;
    transition: opacity 1s ease-in-out;
}

.slider .slide.active {
    opacity: 1;
}
  </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>

  <!-- Logo -->
  <img class="logo" src="images/IMG_20250921_131245.jpg" alt="SKY HIGH Airlines Logo"/> 
  <h1 id="title">SKY HIGH AIRLINES</h1> 

  <!-- Navbar -->
  <ul class="navbar">
    <li><a href="home_page.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
    <li>
      <?php
        if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Customer')
          echo "<a href=\"book_tickets.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> Book Tickets</a>";
        else if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Administrator')
          echo "<a href=\"admin_ticket_message.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> Book Tickets</a>";
        else
          echo "<a href=\"login_page.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> Book Tickets</a>";
      ?>
    </li>
  <li><a href="#contact"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
  <li><a href="terms_and_conditions.php"><i class="fa fa-file-text-o" aria-hidden="true"></i> Terms &amp; Conditions</a></li>
    <li class="right">
      <?php
        if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Customer')
          echo "<a href=\"customer_homepage.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
        else if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Administrator')
          echo "<a href=\"admin_homepage.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
        else
          echo "<a href=\"login_page.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
      ?>
    </li>
  </ul>

  <!-- Hero Section -->
  <div class="container">
    <div class="welcome_text">Welcome to SKY HIGH Airline!</div>
    <div class="slider">
    <img src="images/J.jpeg" class="slide active" alt="Airplane 1">
    <img src="images/JU.jpeg" class="slide" alt="Airplane 2">
    <img src="images/S.jpeg" class="slide" alt="Airplane 3">
    <img src="images/SU.jpeg" class="slide" alt="Airplane 4">
  </div>
</div>

  <!-- Contact & Customer Care Side by Side -->
  <div class="contact-care-flex">
    <div class="contact-section" id="contact">
      <h2>Contact Us</h2>
      <p>If you have any questions or inquiries, feel free to reach out to us using the form below.</p>
      <form action="contact_form_submit.php" method="post" class="contact-form" style="display:flex; flex-direction:column; align-items:center; gap:16px; max-width:400px; margin:0 auto;">
        <input type="text" name="name" placeholder="Your Name" required style="width:100%; max-width:400px;">
        <input type="email" name="email" placeholder="Your Email" required style="width:100%; max-width:400px;">
        <textarea name="message" placeholder="Your Message" rows="5" required style="width:100%; max-width:400px;"></textarea>
        <button type="submit" style="width:100%; max-width:400px;">Send Message</button>
      </form>
    </div>

    <section class="contact-section">
      <h2>Customer Care Details</h2>
      <p><strong>Contact Number:</strong> +91-859-130-7233</p>
      <p><strong>Email ID:</strong> skyhighairline0@gmail.com</p>
    </section>
  </div>

  <!-- Removed footer, now in navbar -->
<script>
let currentSlide = 0;
const slides = document.querySelectorAll(".slider .slide");

setInterval(function () {
    slides[currentSlide].classList.remove("active");
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add("active");
}, 3000);
</script>
</body>
</html>
