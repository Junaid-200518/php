<?php
require_once('Database Connection file/mysqli_connect.php');
require_once('contact_messages_setup.php');

ensure_contact_messages_table($dbc);

// Fetch all messages
$query = "SELECT id, name, email, message, reply, replied_at FROM contact_messages ORDER BY id DESC";
$result = mysqli_query($dbc, $query);
if ($result === false) {
    // Fallback for a database where the reply/replied_at columns still
    // couldn't be added (e.g. restricted permissions) - show messages anyway.
    $query = "SELECT id, name, email, message, NULL as reply, NULL as replied_at FROM contact_messages ORDER BY id DESC";
    $result = mysqli_query($dbc, $query);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Customer Messages - SKY HIGH Airlines</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #e6f0ff; /* light blue background */
            margin: 0;
            padding: 0;
            color: #030337;
        }
        h2 {
            text-align: center;
            margin-top: 40px;
            font-size: 28px;
        }
        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color: #003366;
            color: #fff;
            font-weight: bold;
        }
        tr {
            background-color: #ffffff;
            transition: background 0.3s;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #cce0ff;
        }
        td {
            border-bottom: 1px solid #ddd;
        }
        tr:last-child td {
            border-bottom: none;
        }
        .button-container {
            text-align: center;
            margin-bottom: 40px;
        }
        .button-container button {
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 12px 30px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        .button-container button:hover {
            background-color: #6699ff;
        }
        .reply-box {
            background: #f7faff;
            border: 1px solid #cfe0ff;
            border-radius: 8px;
            padding: 8px 10px;
            margin-top: 6px;
            font-size: 0.95em;
        }
        .reply-box strong { color: #003366; }
        .reply-form textarea {
            width: 100%;
            min-height: 60px;
            box-sizing: border-box;
            border: 1.5px solid #003366;
            border-radius: 6px;
            padding: 8px;
            font-family: inherit;
            font-size: 0.95em;
            resize: vertical;
        }
        .row-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 220px;
        }
        .row-actions button {
            border: none;
            border-radius: 6px;
            padding: 8px 14px;
            font-size: 0.9em;
            cursor: pointer;
            color: #fff;
            transition: 0.3s;
        }
        .btn-reply { background-color: #003366; }
        .btn-reply:hover { background-color: #0055aa; }
        .btn-delete { background-color: #c0392b; }
        .btn-delete:hover { background-color: #e74c3c; }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <h2>Customer Emails / Messages</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Reply</th>
            <th>Actions</th>
        </tr>
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                    <td>
                        <?php if (!empty($row['reply'])): ?>
                            <div class="reply-box">
                                <strong>Replied<?php echo !empty($row['replied_at']) ? ' on '.htmlspecialchars($row['replied_at']) : ''; ?>:</strong><br>
                                <?php echo nl2br(htmlspecialchars($row['reply'])); ?>
                            </div>
                        <?php else: ?>
                            <em style="color:#888;">No reply yet</em>
                        <?php endif; ?>
                        <form class="reply-form" action="admin_message_action_handler.php" method="post" style="margin-top:8px;">
                            <input type="hidden" name="action" value="reply">
                            <input type="hidden" name="message_id" value="<?php echo $row['id']; ?>">
                            <textarea name="reply_text" placeholder="Type a reply..." required><?php echo !empty($row['reply']) ? htmlspecialchars($row['reply']) : ''; ?></textarea>
                            <button type="submit" class="btn-reply" style="margin-top:6px;border:none;border-radius:6px;padding:6px 12px;color:#fff;cursor:pointer;">
                                <?php echo !empty($row['reply']) ? 'Update Reply' : 'Send Reply'; ?>
                            </button>
                        </form>
                    </td>
                    <td>
                        <div class="row-actions">
                            <form action="admin_message_action_handler.php" method="post" onsubmit="return confirm('Delete this message? This cannot be undone.');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="message_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">No messages found.</td></tr>
        <?php endif; ?>
    </table>

    <div class="button-container">
        <a href="admin_homepage.php"><button>Back to Admin Panel</button></a>
    </div>
</body>
</html>
<?php
if ($result) mysqli_free_result($result);
mysqli_close($dbc);
?>
