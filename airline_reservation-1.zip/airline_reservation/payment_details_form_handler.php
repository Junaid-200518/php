<?php
session_start();
?>
<html>
<head>
    <title>Submit Payment Details</title>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
<?php
if(isset($_POST['Pay_Now']))
{
    $no_of_pass    = $_SESSION['no_of_pass'];
    $flight_no     = $_SESSION['flight_no'];
    $journey_date  = $_SESSION['journey_date'];
    $class         = strtolower($_SESSION['class']); // normalize case
    $pnr           = $_SESSION['pnr'];
    $payment_id    = $_SESSION['payment_id'];
    $total_amount  = $_SESSION['total_amount'];
    $payment_date  = $_SESSION['payment_date'];
    $payment_mode  = $_POST['payment_mode'];

    require_once('Database Connection file/mysqli_connect.php');

    // initialize to avoid undefined
    $affected_rows_1 = 0;

    if($class=='economy')
    {
        $query="UPDATE Flight_Details SET seats_economy=seats_economy-? WHERE flight_no=? AND departure_date=?";
        $stmt=mysqli_prepare($dbc,$query);
        mysqli_stmt_bind_param($stmt,"iss",$no_of_pass,$flight_no,$journey_date);
        mysqli_stmt_execute($stmt);
        $affected_rows_1=mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);
    }
    else if($class=='business')
    {
        $query="UPDATE Flight_Details SET seats_business=seats_business-? WHERE flight_no=? AND departure_date=?";
        $stmt=mysqli_prepare($dbc,$query);
        mysqli_stmt_bind_param($stmt,"iss",$no_of_pass,$flight_no,$journey_date);
        mysqli_stmt_execute($stmt);
        $affected_rows_1=mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);
    }

    if($affected_rows_1==1)
    {
        // seats updated, now insert payment details
        $query="INSERT INTO Payment_Details (payment_id,pnr,payment_date,payment_amount,payment_mode) VALUES (?,?,?,?,?)";
        $stmt=mysqli_prepare($dbc,$query);
        mysqli_stmt_bind_param($stmt,"sssis",$payment_id,$pnr,$payment_date,$total_amount,$payment_mode);
        mysqli_stmt_execute($stmt);
        $affected_rows_2=mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);

        if($affected_rows_2==1)
        {
            // Payment success
            header('location:ticket_success.php');
            exit;
        }
        else
        {
            echo "Submit Error inserting payment details: ".mysqli_error($dbc);
        }
    }
    else
    {
        echo "Submit Error updating seats: ".mysqli_error($dbc);
    }

    mysqli_close($dbc);
}
else
{
    echo "Payment request not received";
}
?>
</body>
</html>
