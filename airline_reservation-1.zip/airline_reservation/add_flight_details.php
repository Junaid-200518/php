<?php
	session_start();
?>
<html>
<head>
	<title>Add Flight Schedule - SKY HIGH Airlines</title>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		body {
			margin: 0;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			background: #e6f0ff; /* Light blue background */
			color: #030337;
		}
		.logo {
			height: 70px;
			margin: 15px 20px;
		}
		#title {
			display: inline-block;
			font-size: 28px;
			font-weight: bold;
			color: #030337;
			vertical-align: middle;
		}
		ul {
			list-style: none;
			background: #030337;
			padding: 0;
			margin: 0 0 20px 0;
			overflow: hidden;
			border-radius: 8px;
		}
		ul li {
			float: left;
		}
		ul li a {
			display: block;
			color: #fff;
			padding: 12px 20px;
			text-decoration: none;
			transition: 0.3s;
		}
		ul li a:hover {
			background: #6699ff;
		}
		h2 {
			text-align: center;
			margin: 30px 0 20px;
			color: #030337;
		}
		form {
			background: #fff;
			width: 70%;
			margin: 0 auto 40px auto;
			padding: 25px 40px;
			border-radius: 12px;
			box-shadow: 0 5px 20px rgba(0,0,0,0.1);
		}
		table {
			width: 100%;
			border-collapse: collapse;
			margin-bottom: 20px;
		}
		td {
			padding: 10px;
			font-size: 15px;
		}
		input[type=text], input[type=number], input[type=date], input[type=time] {
			width: 95%;
			padding: 8px 12px;
			border: 1.5px solid #030337;
			border-radius: 5px;
			font-size: 14px;
		}
		input[type=submit] {
			background-color: #030337;
			color: white;
			border-radius: 5px;
			padding: 10px 50px;
			cursor: pointer;
			font-size: 16px;
			transition: 0.3s;
			display: block;
			margin: 30px auto 0 auto;
		}
		input[type=submit]:hover {
			background-color: #6699ff;
		}
		hr {
			border: 0;
			height: 1px;
			background: #030337;
			opacity: 0.2;
			margin: 20px 0;
		}
		.message {
			text-align: center;
			font-weight: bold;
			margin-bottom: 20px;
		}
		.message.success { color: green; }
		.message.error { color: red; }
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<div style="display:flex; align-items:center; padding:10px 20px;">
		<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
		<h1 id="title">SKY HIGH AIRLINES</h1>
	</div>

	<div>
		<ul>
			<li><a href="admin_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="admin_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<form action="add_flight_details_form_handler.php" method="post">
		<h2>Add Flight Schedule Details</h2>
		<?php
			if(isset($_GET['msg']) && $_GET['msg']=='success') {
				echo "<div class='message success'>The Flight Schedule has been successfully added.</div>";
			} else if(isset($_GET['msg']) && $_GET['msg']=='failed') {
				echo "<div class='message error'>*Invalid Flight Schedule Details, please enter again.</div>";
			}
		?>

		<table>
			<tr>
				<td>Flight Number</td>
				<td>Jet ID</td>
			</tr>
			<tr>
				<td><input type="text" name="flight_no" required></td>
				<td><input type="text" name="jet_id" required></td>
			</tr>
		</table>

		<table>
			<tr>
				<td>From</td>
				<td>Destination</td>
			</tr>
			<tr>
				<td><input type="text" name="origin" required></td>
				<td><input type="text" name="destination" required></td>
			</tr>
		</table>

		<table>
			<tr>
				<td>Departure Date</td>
				<td>Arrival Date</td>
			</tr>
			<tr>
				<td><input type="date" name="dep_date" required></td>
				<td><input type="date" name="arr_date" required></td>
			</tr>
		</table>

		<table>
			<tr>
				<td>Departure Time</td>
				<td>Arrival Time</td>
			</tr>
			<tr>
				<td><input type="time" name="dep_time" required></td>
				<td><input type="time" name="arr_time" required></td>
			</tr>
		</table>

		<table>
			<tr>
				<td>Seats (Economy Class)</td>
				<td>Seats (Business Class)</td>
			</tr>
			<tr>
				<td><input type="number" name="seats_eco" required></td>
				<td><input type="number" name="seats_bus" required></td>
			</tr>
		</table>

		<table>
			<tr>
				<td>Ticket Price (Economy Class)</td>
				<td>Ticket Price (Business Class)</td>
			</tr>
			<tr>
				<td><input type="number" name="price_eco" required></td>
				<td><input type="number" name="price_bus" required></td>
			</tr>
		</table>

		<input type="submit" value="Submit" name="Submit">
	</form>
</body>
</html>
