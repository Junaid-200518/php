<!DOCTYPE html>
<html>
<head>
    <title>Terms and Conditions - SKY HIGH Airlines</title>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        /* Global */
        body {
            font-family: 'Roboto', Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #202124;
        }

        /* Top toolbar (like Gmail) */
        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #ffffff;
            padding: 10px 24px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .top-bar .logo {
            height: 40px;
        }

        .top-bar h1 {
            font-size: 20px;
            font-weight: 500;
            margin: 0 0 0 16px;
            color: #202124;
        }

        .top-bar .back-btn {
            font-size: 14px;
            font-weight: 500;
            padding: 8px 16px;
            color: #fff;
            background-color: #1a73e8;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .top-bar .back-btn:hover {
            background-color: #1669c1;
        }

        /* Container */
        .container {
            max-width: 800px;
            margin: 40px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 40px 30px;
        }

        h2 {
            color: #202124;
            font-weight: 500;
            margin-bottom: 24px;
            text-align: center;
            font-size: 24px;
            text-decoration: underline;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        ul li {
            background: #f1f3f4;
            margin-bottom: 12px;
            padding: 12px 16px;
            border-left: 5px solid #1a73e8;
            border-radius: 4px;
            font-size: 15px;
            line-height: 1.5;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .container {
                padding: 30px 20px;
                margin: 20px 10px;
            }

            h2 {
                font-size: 20px;
            }

            .top-bar h1 {
                font-size: 18px;
            }
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>

    <!-- Top Toolbar -->
    <div class="top-bar">
        <div style="display:flex; align-items:center;">
            <img src="images/IMG_20250921_131245.jpg" alt="SK Airlines Logo" class="logo">
            <h1>SKY HIGH Airlines</h1>
        </div>
        <a href="home_page.php" class="back-btn"><i class="fa fa-home"></i> Back to Home</a>
    </div>

    <!-- Terms Container -->
    <div class="container">
        <h2>Terms and Conditions</h2>
        <div style="font-size:16px; color:#222; line-height:1.7;">
        <p><strong>Welcome to SKY HIGH Airlines. By booking a ticket through our platform, you agree to the following terms and conditions:</strong></p>
        <ol style="margin-left:20px;">
            <li><strong>Ticket Booking</strong><br>
                All bookings are subject to availability.<br>
                Ticket confirmation is valid only after successful payment.
            </li>
            <li><strong>Ticket Cancellation</strong><br>
                Passengers may cancel their tickets at any time before the scheduled departure.<br>
                Cancellation requests must be submitted through our official website or customer service portal.
            </li>
            <li><strong>Refund Policy</strong><br>
                Refunds are available for canceled tickets; however, a cancellation fee will apply.<br>
                The cancellation fee depends on the time of cancellation:
                <ul style="margin-top:6px;">
                    <li>More than 7 days before departure: 10% of ticket price will be deducted.</li>
                    <li>3–7 days before departure: 25% of ticket price will be deducted.</li>
                    <li>Less than 3 days before departure: 50% of ticket price will be deducted.</li>
                </ul>
                Refunds will be processed using the same payment method used during booking and may take 5–7 business days.
            </li>
            <li><strong>Non-Refundable Tickets</strong><br>
                Some promotional or discounted tickets may be non-refundable. Such restrictions will be clearly indicated at the time of booking.
            </li>
            <li><strong>Changes to Booking</strong><br>
                Date or route changes are allowed depending on seat availability and may incur additional fees.<br>
                Any change must be requested before the scheduled departure.
            </li>
            <li><strong>Passenger Responsibility</strong><br>
                Passengers are responsible for providing accurate personal and travel information.<br>
                Valid identification is required at the time of check-in.
            </li>
            <li><strong>Liability</strong><br>
                SKY HIGH Airlines is not responsible for delays or cancellations due to events beyond our control, including weather, natural disasters, or government regulations.
            </li>
            <li><strong>Governing Law</strong><br>
                These terms and conditions are governed by the laws of India.
            </li>
        </ol>
        </div>
    </div>

</body>
</html>
