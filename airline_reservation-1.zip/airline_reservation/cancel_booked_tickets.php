<?php
	session_start();
?>
<html>
<head>
	<title>Cancel Booked Tickets</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		/* Background + typography */
		body {
			margin: 0;
			font-family: 'Segoe UI', sans-serif;
			background: linear-gradient(135deg,#e8f1f8,#ffffff);
			color:#333;
		}
		.logo {
			height: 70px;
			margin:15px;
		}
		#title {
			display:inline-block;
			font-size: 28px;
			font-weight: bold;
			letter-spacing: 2px;
			vertical-align: middle;
			color:#030337;
		}
		ul {
			list-style-type:none;
			background-color:#030337;
			padding:0;
			margin:0;
			overflow:hidden;
		}
		ul li {
			float:left;
		}
		ul li a {
			display:block;
			color:#fff;
			padding:14px 20px;
			text-decoration:none;
			transition:background 0.3s ease;
		}
		ul li a:hover {
			background:#00509E;
		}
		/* Card container */
		.form-card {
			background:#fff;
			max-width:500px;
			margin:40px auto;
			padding:30px;
			border-radius:10px;
			box-shadow:0 4px 20px rgba(0,0,0,0.1);
		}
		.form-card h2 {
			text-align:center;
			color:#030337;
			margin-bottom:20px;
		}
		.form-card table {
			width:100%;
		}
		.form-card td {
			font-size:16px;
			padding:5px 0;
		}
		input[type=text] {
			width:100%;
			border:1.5px solid #030337;
			border-radius:6px;
			padding:10px;
			font-size:15px;
			box-sizing:border-box;
		}
		input[type=submit] {
			display:block;
			background-color:#030337;
			color:white;
			border:none;
			border-radius:6px;
			padding:12px;
			width:100%;
			font-size:16px;
			font-weight:600;
			margin-top:15px;
			cursor:pointer;
			transition:background 0.3s ease;
		}
		input[type=submit]:hover {
			background:#00509E;
		}
		.error {
			color:red;
			font-weight:600;
			text-align:center;
			display:block;
			margin-bottom:10px;
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
	<h1 id="title">SKY HIGH AIRLINES</h1>

	<div>
		<ul>
			<li><a href="customer_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="customer_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<div class="form-card">
		<h2>CANCEL BOOKED TICKETS</h2>
		<?php
			if(isset($_GET['msg']) && $_GET['msg']=='failed')
			{
				echo "<span class='error'>*Invalid PNR, please enter PNR again</span>";
			}
		?>
		<form action="cancel_booked_tickets_form_handler.php" method="post">
			<table>
				<tr>
					<td>Enter the PNR</td>
				</tr>
				<tr>
					<td><input type="text" name="pnr" placeholder="Enter your PNR number" required></td>
				</tr>
			</table>
			<input type="submit" value="Cancel Ticket" name="Cancel_Ticket">
		</form>
	</div>
</body>
</html>
