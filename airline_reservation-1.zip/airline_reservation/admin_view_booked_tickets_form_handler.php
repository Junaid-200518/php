<?php
	session_start();
?>
<html>
<head>
	<title>Booked Tickets - SKY HIGH Airlines</title>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		body {
			margin: 0;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			background: #e6f0ff; /* Light blue background */
			color: #030337;
		}
		.logo {
			height: 70px;
			margin: 15px 20px;
		}
		#title {
			display: inline-block;
			font-size: 28px;
			font-weight: bold;
			color: #030337;
			vertical-align: middle;
		}
		ul {
			list-style: none;
			background: #030337;
			padding: 0;
			margin: 0;
			overflow: hidden;
			border-radius: 8px;
		}
		ul li {
			float: left;
		}
		ul li a {
			display: block;
			color: #fff;
			padding: 12px 20px;
			text-decoration: none;
			transition: 0.3s;
		}
		ul li a:hover {
			background: #6699ff;
		}
		h2 {
			text-align: center;
			margin: 30px 0 20px;
			color: #030337;
		}
		table {
			border-collapse: collapse;
			width: 90%;
			margin: 0 auto 40px auto;
			background: #fff;
			box-shadow: 0 5px 15px rgba(0,0,0,0.1);
			border-radius: 8px;
			overflow: hidden;
		}
		th, td {
			padding: 12px 15px;
			text-align: center;
			border-bottom: 1px solid #ddd;
		}
		th {
			background: #030337;
			color: #fff;
			font-size: 16px;
		}
		tr:hover {
			background: #f2f9ff;
		}
		h3 {
			text-align: center;
			margin-top: 20px;
			color: #030337;
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<div style="display:flex; align-items:center; padding:10px 20px;">
		<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
		<h1 id="title">SKY HIGH AIRLINES</h1>
	</div>

	<div>
		<ul>
			<li><a href="admin_homepage.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="admin_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<h2>List of Booked Tickets for the Flight</h2>

	<?php
	if(isset($_POST['Submit']))
	{
		$data_missing=array();
		if(empty($_POST['flight_no']))
		{
			$data_missing[]='Flight No.';
		}
		else
		{
			$flight_no=trim($_POST['flight_no']);
		}
		if(empty($_POST['departure_date']))
		{
			$data_missing[]='Departure Date';
		}
		else
		{
			$departure_date=$_POST['departure_date'];
		}

		if(empty($data_missing))
		{
			require_once('Database Connection file/mysqli_connect.php');
			$query="SELECT pnr,date_of_reservation,class,no_of_passengers,payment_id,customer_id FROM Ticket_Details WHERE flight_no=? AND journey_date=? AND booking_status='CONFIRMED' ORDER BY class";
			$stmt=mysqli_prepare($dbc,$query);
			mysqli_stmt_bind_param($stmt,"ss",$flight_no,$departure_date);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_bind_result($stmt,$pnr,$date_of_reservation,$class,$no_of_passengers,$payment_id,$customer_id);
			mysqli_stmt_store_result($stmt);
			if(mysqli_stmt_num_rows($stmt)==0)
			{
				echo "<h3>No booked tickets found for Flight <strong>$flight_no</strong> on <strong>$departure_date</strong>!</h3>";
			}
			else
			{
				echo "<table>";
				echo "<tr><th>PNR</th>
				<th>Date of Reservation</th>
				<th>Class</th>
				<th>No. of Passengers</th>
				<th>Payment ID</th>
				<th>Customer ID</th>
				</tr>";
				while(mysqli_stmt_fetch($stmt)) {
					echo "<tr>
					<td>".$pnr."</td>
					<td>".$date_of_reservation."</td>
					<td>".$class."</td>
					<td>".$no_of_passengers."</td>
					<td>".$payment_id."</td>
					<td>".$customer_id."</td>
					</tr>";
				}
				echo "</table>";
			}
			mysqli_stmt_close($stmt);
			mysqli_close($dbc);
		}
		else
		{
			echo "<h3 style='color:red; text-align:center'>The following fields were empty:</h3>";
			foreach($data_missing as $missing)
			{
				echo "<h3 style='color:red; text-align:center'>$missing</h3>";
			}
		}
	}
	else
	{
		echo "<h3 style='text-align:center'>Submit request not received.</h3>";
	}
	?>
</body>
</html>
