<?php
	session_start();
?>
<html>
<head>
	<title>View Available Flights</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		/* Global */
		body {
			margin: 0;
			font-family: 'Segoe UI', sans-serif;
			background: linear-gradient(135deg, #e0f7fa, #f1f8ff);
			color: #333;
			min-height: 100vh;
		}

		.logo {
			width: 120px;
			display: block;
			margin: 20px auto;
			border-radius: 12px;
			box-shadow: 0 4px 8px rgba(0,0,0,0.2);
		}

		#title {
			text-align: center;
			color: #0056b3;
			margin: 0;
			font-size: 2rem;
		}

		/* Navbar */
		ul {
			list-style: none;
			margin: 20px 0 0 0;
			padding: 0;
			display: flex;
			justify-content: center;
			background: #0056b3;
			flex-wrap: wrap;
		}

		ul li a {
			display: block;
			padding: 14px 25px;
			text-decoration: none;
			color: #fff;
			transition: background 0.3s ease;
		}

		ul li a:hover {
			background: #003f80;
		}

		h2 {
			text-align: center;
			margin-top: 30px;
			color: #0056b3;
		}

		/* Table wrapper */
		.table-card {
			background: #fff;
			max-width: 95%;
			margin: 20px auto;
			padding: 20px;
			border-radius: 12px;
			box-shadow: 0 8px 18px rgba(0,0,0,0.1);
			overflow-x: auto;
		}

		table {
			width: 100%;
			border-collapse: collapse;
		}

		th {
			background: #0056b3;
			color: #fff;
			padding: 12px;
			text-align: left;
			font-weight: normal;
		}

		td {
			padding: 10px 12px;
			border-bottom: 1px solid #ddd;
		}

		tr:hover td {
			background-color: #f9f9f9;
		}

		input[type=radio] {
			transform: scale(1.2);
			accent-color: #0056b3;
		}

		input[type=submit] {
			display: block;
			background: linear-gradient(135deg, #0056b3, #003f80);
			color: #fff;
			border: none;
			font-weight: bold;
			cursor: pointer;
			width: 250px;
			padding: 12px;
			margin: 25px auto 0 auto;
			border-radius: 6px;
			font-size: 16px;
			transition: background 0.3s ease;
		}

		input[type=submit]:hover {
			background: linear-gradient(135deg, #003f80, #00295d);
		}

		h3 {
			text-align: center;
			color: #e53935;
		}

		@media (max-width: 600px) {
			th, td {
				font-size: 13px;
			}
			input[type=submit] {
				width: 90%;
			}
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<img class="logo" src="images/IMG_20250921_131245.jpg"/>
	<h1 id="title">SKY HIGH AIRLINES</h1>

	<div>
		<ul>
			<li><a href="home_page.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="customer_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<h2><i class="fa fa-plane"></i> AVAILABLE FLIGHTS</h2>

	<?php
		if(isset($_POST['Search']))
		{
			$data_missing=array();
			if(empty($_POST['origin'])){$data_missing[]='Origin';}else{$origin=$_POST['origin'];}
			if(empty($_POST['destination'])){$data_missing[]='Destination';}else{$destination=$_POST['destination'];}
			if(empty($_POST['dep_date'])){$data_missing[]='Departure Date';}else{$dep_date=trim($_POST['dep_date']);}
			if(empty($_POST['no_of_pass'])){$data_missing[]='No. of Passengers';}else{$no_of_pass=trim($_POST['no_of_pass']);}
			if(empty($_POST['class'])){$data_missing[]='Class';}else{$class=($_POST['class']);}
			$no_of_child = (isset($_POST['no_of_child']) && $_POST['no_of_child'] !== '') ? (int)trim($_POST['no_of_child']) : 0;

			if(empty($data_missing))
			{
				// total seats needed covers both adult passengers and children (children still occupy a seat)
				$total_seats_needed = $no_of_pass + $no_of_child;
				$_SESSION['no_of_pass']=$no_of_pass;
				$_SESSION['no_of_child']=$no_of_child;
				$_SESSION['class']=$class;
				$count=1;
				$_SESSION['count']=$count;
				$_SESSION['journey_date']=$dep_date;
				require_once('Database Connection file/mysqli_connect.php');
				if($class=="Economy")
				{
					$query="SELECT flight_no,from_city,to_city,departure_date,departure_time,arrival_date,arrival_time,price_economy FROM Flight_Details where from_city=? and to_city=? and departure_date=? and seats_economy>=? ORDER BY  departure_time";
					$stmt=mysqli_prepare($dbc,$query);
					mysqli_stmt_bind_param($stmt,"sssi",$origin,$destination,$dep_date,$total_seats_needed);
					mysqli_stmt_execute($stmt);
					mysqli_stmt_bind_result($stmt,$flight_no,$from_city,$to_city,$departure_date,$departure_time,$arrival_date,$arrival_time,$price_economy);
					mysqli_stmt_store_result($stmt);
					if(mysqli_stmt_num_rows($stmt)==0)
					{
						echo "<h3>No flights are available !</h3>";
					}
					else
					{
						echo "<form action=\"book_tickets2.php\" method=\"post\">";
						echo "<input type=\"hidden\" name=\"no_of_pass\" value=\"".$no_of_pass."\">";
						echo "<input type=\"hidden\" name=\"no_of_child\" value=\"".$no_of_child."\">";
						echo "<input type=\"hidden\" name=\"class\" value=\"".$class."\">";
						echo "<input type=\"hidden\" name=\"journey_date\" value=\"".$dep_date."\">";
						echo "<div class='table-card'>";
						echo "<table>";
						echo "<tr><th>Flight No.</th>
						<th>Origin</th>
						<th>Destination</th>
						<th>Departure Date</th>
						<th>Departure Time</th>
						<th>Arrival Date</th>
						<th>Arrival Time</th>
						<th>Price (Economy)</th>
						<th>Select</th>
						</tr>";
						while(mysqli_stmt_fetch($stmt)) {
							echo "<tr>
							<td>".$flight_no."</td>
							<td>".$from_city."</td>
							<td>".$to_city."</td>
							<td>".$departure_date."</td>
							<td>".$departure_time."</td>
							<td>".$arrival_date."</td>
							<td>".$arrival_time."</td>
							<td>&#x20b9; ".$price_economy."</td>
							<td><input type=\"radio\" name=\"flight_no\" value=\"".$flight_no."\"></td>
							</tr>";
						}
						echo "</table>";
						echo "</div>";
						echo "<input type=\"submit\" value=\"Select Flight\" name=\"Select\" id=\"selectFlightBtn\">";
						echo "</form>";
													echo '<script>
	const form = document.querySelector("form[action=\\"book_tickets2.php\\"]");
	if (form) {
		form.addEventListener("submit", function(e) {
			const checked = form.querySelector("input[type=radio][name=flight_no]:checked");
			if (!checked) {
				alert("Please select a flight before proceeding.");
				e.preventDefault();
			}
		});
	}
	</script>';
					}
				}
				else if($class=="Business")
				{
					$query="SELECT flight_no,from_city,to_city,departure_date,departure_time,arrival_date,arrival_time,price_business FROM Flight_Details where from_city=? and to_city=? and departure_date=? and seats_business>=? ORDER BY  departure_time";
					$stmt=mysqli_prepare($dbc,$query);
					mysqli_stmt_bind_param($stmt,"sssi",$origin,$destination,$dep_date,$total_seats_needed);
					mysqli_stmt_execute($stmt);
					mysqli_stmt_bind_result($stmt,$flight_no,$from_city,$to_city,$departure_date,$departure_time,$arrival_date,$arrival_time,$price_business);
					mysqli_stmt_store_result($stmt);
					if(mysqli_stmt_num_rows($stmt)==0)
					{
						echo "<h3>No flights are available !</h3>";
					}
					else
					{
						echo "<form action=\"book_tickets2.php\" method=\"POST\">";
						echo "<input type=\"hidden\" name=\"no_of_pass\" value=\"".$no_of_pass."\">";
						echo "<input type=\"hidden\" name=\"no_of_child\" value=\"".$no_of_child."\">";
						echo "<input type=\"hidden\" name=\"class\" value=\"".$class."\">";
						echo "<div class='table-card'>";
						echo "<table>";
						echo "<tr><th>Flight No.</th>
						<th>Origin</th>
						<th>Destination</th>
						<th>Departure Date</th>
						<th>Departure Time</th>
						<th>Arrival Date</th>
						<th>Arrival Time</th>
						<th>Price (Business)</th>
						<th>Select</th>
						</tr>";
						while(mysqli_stmt_fetch($stmt)) {
							echo "<tr>
							<td>".$flight_no."</td>
							<td>".$from_city."</td>
							<td>".$to_city."</td>
							<td>".$departure_date."</td>
							<td>".$departure_time."</td>
							<td>".$arrival_date."</td>
							<td>".$arrival_time."</td>
							<td>&#x20b9; ".$price_business."</td>
							<td><input type=\"radio\" name=\"flight_no\" value=\"".$flight_no."\"></td>
							</tr>";
						}
						echo "</table>";
						echo "</div>";
		
						echo "<input type=\"hidden\" name=\"journey_date\" value=\"".$dep_date."\">";
						echo "<input type=\"submit\" value=\"Select Flight\" name=\"Select\" id=\"selectFlightBtnBiz\">";
						echo "</form>";
						echo '<script>
	const formBiz = document.querySelector("form[action=\\"book_tickets2.php\\"]");
	if (formBiz) {
		formBiz.addEventListener("submit", function(e) {
			const checked = formBiz.querySelector("input[type=radio][name=flight_no]:checked");
			if (!checked) {
				alert("Please select a flight before proceeding.");
				e.preventDefault();
			}
		});
	}
	</script>';
					}
				}
				if (isset($stmt) && $stmt) {
					mysqli_stmt_close($stmt);
				}
				mysqli_close($dbc);
			}
			else
			{
				echo "<h3>The following data fields were empty!<br>";
				foreach($data_missing as $missing)
				{
					echo $missing ."<br>";
				}
				echo "</h3>";
			}
		}
		else
		{
			echo "<h3>Search request not received</h3>";
		}
	?>
</body>
</html>
