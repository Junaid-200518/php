<?php
	session_start();
?>
<html>
<head>
	<title>Cancel Booked Tickets</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style>
		body {
			margin: 0;
			font-family: 'Segoe UI', sans-serif;
			background: linear-gradient(135deg,#e8f1f8,#ffffff);
			color:#333;
		}
		.logo {
			height:70px;
			margin:15px;
		}
		#title {
			display:inline-block;
			font-size:28px;
			font-weight:bold;
			letter-spacing:2px;
			vertical-align:middle;
			color:#030337;
		}
		ul {
			list-style-type:none;
			background-color:#030337;
			padding:0;
			margin:0;
			overflow:hidden;
		}
		ul li {
			float:left;
		}
		ul li a {
			display:block;
			color:#fff;
			padding:14px 20px;
			text-decoration:none;
			transition:background 0.3s ease;
		}
		ul li a:hover {
			background:#00509E;
		}
		.success-card {
			max-width:600px;
			margin:60px auto;
			background:#fff;
			padding:30px 40px;
			border-radius:12px;
			box-shadow:0 4px 20px rgba(0,0,0,0.1);
			text-align:center;
		}
		.success-card h2 {
			color:#030337;
			font-size:24px;
			margin-bottom:15px;
		}
		.success-card h3 {
			font-size:18px;
			font-weight:normal;
			line-height:1.6;
			color:#444;
		}
		.success-icon {
			font-size:50px;
			color:green;
			margin-bottom:10px;
		}
		.back-btn {
			display:inline-block;
			margin-top:25px;
			background-color:#030337;
			color:#fff;
			padding:12px 30px;
			border-radius:6px;
			text-decoration:none;
			font-weight:600;
			transition:background 0.3s ease;
		}
		.back-btn:hover {
			background:#00509E;
		}
	</style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
	<img class="logo" src="images/IMG_20250921_131245.jpg"/> 
	<h1 id="title">SKY HIGH AIRLINES</h1>

	<div>
		<ul>
			<li><a href="home_page.php"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="customer_homepage.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
			<li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
			<li><a href="logout_handler.php"><i class="fa fa-sign-out"></i> Logout</a></li>
		</ul>
	</div>

	<div class="success-card">
		<i class="fa fa-check-circle success-icon"></i>
		<h2>CANCEL BOOKED TICKETS</h2>
		<h3>
			Your ticket has been cancelled successfully.<br><br>
			Your amount of &#x20b9; <?php echo $_SESSION['refund_amount']?> will be refunded to your bank account.<br>
			<span style="font-size:15px;color:#888;">(Cancellation charge of 15% of your ticket amount has been deducted)</span>
		</h3>
		<a href="customer_homepage.php" class="back-btn"><i class="fa fa-arrow-left"></i> Back to Dashboard</a>
	</div>
</body>
</html>
