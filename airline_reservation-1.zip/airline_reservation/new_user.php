<html>
<head>
    <title>Create New User Account - SKY HIGH Airlines</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #e6f0ff; /* light blue background */
            margin: 0;
            padding: 0;
            color: #030337;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
            color: #003366;
        }
        .logo {
            display: block;
            margin: 20px auto;
            max-width: 150px;
            border-radius: 10px;
        }
        #title {
            text-align: center;
            color: #003366;
            margin-bottom: 10px;
        }
        ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            overflow: hidden;
            background-color: #003366;
        }
        ul li {
            float: left;
        }
        ul li a {
            display: block;
            color: white;
            text-align: center;
            padding: 12px 20px;
            text-decoration: none;
            font-weight: bold;
        }
        ul li a:hover {
            background-color: #6699ff;
        }
        form.center_form {
            background-color: #ffffff;
            width: 60%;
            margin: 30px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        table strong {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
            color: #003366;
        }
        td {
            padding: 10px 5px;
        }
        input[type=text], input[type=password] {
            width: 90%;
            padding: 8px;
            border: 1.5px solid #003366;
            border-radius: 5px;
            font-size: 14px;
        }
        input[type=submit] {
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 40px;
            font-size: 16px;
            cursor: pointer;
            display: block;
            margin: 0 auto;
            transition: 0.3s;
        }
        input[type=submit]:hover {
            background-color: #6699ff;
        }
    </style>
  <link rel="stylesheet" href="css/theme.css">
</head>
<body>
    <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
    <h1 id="title">SKY HIGH AIRLINES</h1>

    <ul>
        <li><a href="home_page.php"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="login_page.php"><i class="fa fa-ticket"></i> Book Tickets</a></li>
        <li><a href="home_page.php"><i class="fa fa-phone"></i> Contact Us</a></li>
        <li><a href="login_page.php"><i class="fa fa-sign-in"></i> Login</a></li>
    </ul>

    <form class="center_form" action="new_user_form_handler.php" method="POST" id="new_user_form">
        <h2><i class="fa fa-user-plus"></i> CREATE NEW USER ACCOUNT</h2>

        <table>
            <strong>ENTER LOGIN DETAILS</strong>
            <tr>
                <td>Username</td>
                <td><input type="text" name="username" required></td>
            </tr>
            <tr>
                <td>Password (max 6 chars)</td>
                <td><input type="password" name="password" id="password" maxlength="6" required></td>
            </tr>
            <tr>
                <td>Confirm Password</td>
                <td><input type="password" name="confirm_password" id="confirm_password" maxlength="6" required></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" name="email" required></td>
            </tr>
        </table>

        <table>
            <strong>ENTER PERSONAL DETAILS</strong>
            <tr>
                <td>Name</td>
                <td><input type="text" name="name" required></td>
            </tr>
            <tr>
                <td>Phone No.</td>
                <td><input type="text" name="phone_no" required></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><input type="text" name="address" required></td>
            </tr>
        </table>

        <input type="submit" value="Submit" name="Submit" onclick="return validatePassword();">
    </form>

    <script>
        function validatePassword() {
            var pass = document.getElementById('password').value;
            var confirmPass = document.getElementById('confirm_password').value;
            if(pass !== confirmPass) {
                alert('Passwords do not match!');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
