<?php
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}
?>
<html>
<head>
  <title>Account Login</title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">

  <style>
    /* Background */
    body {
      margin: 0;
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg,#e0eafc 0%,#cfdef3 100%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    /* Logo & Title */
    .logo {
      display: block;
      margin: 30px auto 10px;
      width: 100px;
      height: 100px;
      object-fit: cover;
      border-radius: 50%;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    #title {
      text-align: center;
      font-size: 2rem;
      font-weight: 700;
      color: #003366;
      margin: 5px 0 20px;
      text-shadow: 1px 1px 4px rgba(0,0,0,0.05);
    }

    /* Navbar */
    ul {
      list-style: none;
      margin: 0;
      padding: 8px 0;
      background: #003366;
      text-align: center;
      width: 100%;
      border-radius: 0 0 12px 12px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.07);
    }
    ul li {
      display: inline-block;
      margin: 0 10px;
    }
    ul li a {
      color: #fff;
      text-decoration: none;
      padding: 10px 16px;
      border-radius: 6px;
      font-weight: 500;
      transition: 0.3s;
    }
    ul li a:hover {
      background: #ff6600;
      box-shadow: 0 2px 8px rgba(255,102,0,0.2);
    }

    /* Login Form Card */
    .float_form {
      background: #fff;
      padding: 35px 40px;
      margin-top: 40px;
      border-radius: 16px;
      max-width: 400px;
      width: 90%;
      box-shadow: 0 8px 24px rgba(0,0,0,0.08);
      animation: fadeIn 0.8s ease;
    }

    fieldset {
      border: none;
      padding: 0;
      margin: 0;
    }

    legend {
      font-size: 1.3rem;
      font-weight: 600;
      color: #003366;
      margin-bottom: 15px;
    }

    strong {
      color: #333;
    }

    /* Inputs */
    input[type=text],
    input[type=password] {
      width: 100%;
      border: 1.5px solid #003366;
      border-radius: 6px;
      padding: 10px 12px;
      margin-top: 6px;
      margin-bottom: 16px;
      font-size: 0.95rem;
      background: #f7faff;
      transition: 0.25s;
    }
    input[type=text]:focus,
    input[type=password]:focus {
      border-color: #ff6600;
      outline: none;
      box-shadow: 0 0 6px rgba(255,102,0,0.2);
    }

    /* Radio buttons */
    .radio-group {
      display: flex;
      gap: 10px;
      align-items: center;
      margin-bottom: 15px;
      font-size: 0.95rem;
    }

    /* Submit button */
    input[type=submit] {
      display: block;
      width: 100%;
      background: #003366;
      color: #fff;
      border: none;
      border-radius: 6px;
      padding: 12px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
      margin-top: 10px;
    }
    input[type=submit]:hover {
      background: #ff6600;
      box-shadow: 0 4px 12px rgba(255,102,0,0.2);
    }

    /* Create Account Link */
    .float_form a {
      display: block;
      margin-top: 15px;
      text-align: center;
      text-decoration: none;
      color: #003366;
      font-weight: 500;
      transition: 0.3s;
    }
    .float_form a:hover {
      color: #ff6600;
    }

    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(20px);}
      to {opacity: 1; transform: translateY(0);}
    }

  </style>
  <link rel="stylesheet" href="css/theme.css">
</head>

<body>
  <!-- Logo & Title -->
  <img class="logo" src="images/IMG_20250921_131245.jpg"/> 
  <h1 id="title">SKY HIGH AIRLINES</h1>

  <!-- Navbar -->
  <div>
    <ul>
      <li><a href="home_page.php"><i class="fa fa-home"></i> Home</a></li>
      <li><a href="login_page.php"><i class="fa fa-ticket"></i> Book Tickets</a></li>
      <li><a href="home_page.php#contact"><i class="fa fa-phone"></i> Contact Us</a></li>
      <li><a href="login_page.php"><i class="fa fa-sign-in"></i> Login</a></li>
    </ul>
  </div>

  <!-- Login Form -->
  <form class="float_form" action="login_handler.php" method="POST">
    <fieldset>
      <legend><i class="fa fa-lock"></i> Login Details</legend>

      <strong>Username:</strong>
      <input type="text" name="username" placeholder="Enter your username" required>

      <strong>Password:</strong>
      <input type="password" name="password" placeholder="Enter your password" required>

      <strong>User Type:</strong>
      <div class="radio-group">
        <label>Customer <input type='radio' name='user_type' value='Customer' checked/></label>
        <label>Administrator <input type='radio' name='user_type' value='Administrator'/></label>
      </div>

      <?php
        if(isset($_GET['msg']) && $_GET['msg']=='failed'){
          echo "<strong style='color:red'>Invalid Username/Password</strong>";
        }
      ?>
      <input type="submit" name="Login" value="Login">
    </fieldset>

      <div style="text-align:center; margin-top:10px;">
          <a href="reset_password.php" style="font-size:14px; color:#003366; text-decoration:underline;">Reset Password?</a>
      </div>
    <a href="new_user.php"><i class="fa fa-user-plus"></i> Create New User Account?</a>
  </form>
</body>
</html>
